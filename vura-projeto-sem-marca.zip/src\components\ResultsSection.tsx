import FadeIn from "./FadeIn";
import { TrendingUp, Target, Trophy, Smartphone, Settings2, BarChart3 } from "lucide-react";

const pillars = [
  {
    icon: TrendingUp,
    emoji: "📈",
    title: "Aquisição de alunos",
    desc: "Criamos campanhas para atrair novos alunos, clientes e oportunidades de forma previsível.",
  },
  {
    icon: Target,
    emoji: "🎯",
    title: "Gestão de tráfego pago",
    desc: "Planejamos, configuramos, testamos e otimizamos campanhas para gerar demanda qualificada.",
  },
  {
    icon: Trophy,
    emoji: "🏆",
    title: "Posicionamento estratégico",
    desc: "Estruturamos a comunicação para destacar sua marca dentro do mercado esportivo.",
  },
  {
    icon: Smartphone,
    emoji: "📱",
    title: "Conteúdo de autoridade",
    desc: "Criamos uma presença digital que gera confiança e fortalece sua percepção de valor.",
  },
  {
    icon: Settings2,
    emoji: "⚙️",
    title: "Funil de captação",
    desc: "Organizamos o caminho entre atenção, interesse e conversão para evitar perda de oportunidades.",
  },
  {
    icon: BarChart3,
    emoji: "📊",
    title: "Performance e otimização",
    desc: "Acompanhamos métricas, identificamos gargalos e tomamos decisões baseadas em dados.",
  },
];

const ResultsSection = () => {
  return (
    <section
      id="resultados"
      className="py-20 sm:py-28 px-4 sm:px-6 md:px-12 bg-background border-t border-border/60"
    >
      <div className="container mx-auto max-w-[1200px]">
        <FadeIn>
          <div className="flex items-center gap-3 text-xs font-bold tracking-[4px] uppercase text-primary mb-5">
            <span className="w-8 h-0.5 bg-primary" />
            Pilares do crescimento
          </div>
          <h2 className="font-display text-[clamp(2rem,5vw,4.5rem)] tracking-wide leading-[0.95] uppercase max-w-[900px]">
            O que operamos dentro do{" "}
            <span className="text-primary">Método 30/30.</span>
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg max-w-[680px] mt-6 leading-relaxed">
            Não são entregáveis soltos. São os seis componentes que, integrados, geram
            crescimento previsível em negócios esportivos.
          </p>
        </FadeIn>

        <div className="mt-12 sm:mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {pillars.map((p, i) => (
            <FadeIn key={p.title} delay={i * 80}>
              <div className="bg-card border border-border rounded-xl p-7 sm:p-8 h-full hover:border-primary/50 transition-colors group">
                <div className="flex items-center gap-4 mb-5">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                    <p.icon className="w-5 h-5 text-primary" />
                  </div>
                  <span className="text-2xl" aria-hidden>
                    {p.emoji}
                  </span>
                </div>
                <h3 className="font-display text-2xl sm:text-3xl tracking-wide uppercase mb-3">
                  {p.title}
                </h3>
                <p className="text-muted-foreground text-sm sm:text-base leading-relaxed">
                  {p.desc}
                </p>
              </div>
            </FadeIn>
          ))}
        </div>

        <FadeIn delay={200}>
          <p className="mt-12 text-center text-[0.7rem] font-bold tracking-[3px] uppercase text-muted-foreground">
            Componentes integrados · Operação contínua · Crescimento mensurável
          </p>
        </FadeIn>
      </div>
    </section>
  );
};

export default ResultsSection;
