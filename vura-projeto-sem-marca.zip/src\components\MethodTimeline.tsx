import FadeIn from "./FadeIn";

const phases = [
  {
    number: "01",
    title: "Estruturar",
    duration: "30 dias",
    objective: "Construir a base do crescimento.",
    pillars: [
      "Diagnóstico do negócio",
      "Posicionamento",
      "Identidade da marca",
      "Estratégia digital",
      "Ativação das redes sociais",
      "Configuração dos anúncios",
      "Definição de metas",
    ],
  },
  {
    number: "02",
    title: "Escalar",
    duration: "30 dias",
    objective: "Acelerar o que já foi validado.",
    pillars: [
      "Otimização baseada em dados",
      "Escala dos anúncios",
      "Conteúdo de autoridade",
      "Automação da captação",
      "Relatórios de performance",
      "Crescimento previsível",
    ],
  },
];

const MethodTimeline = () => {
  return (
    <section
      id="metodo"
      className="py-20 sm:py-28 px-4 sm:px-6 md:px-12 bg-background border-t border-border/60"
    >
      <div className="container mx-auto max-w-[1200px]">
        <FadeIn>
          <div className="flex items-center gap-3 text-xs font-bold tracking-[4px] uppercase text-primary mb-5">
            <span className="w-8 h-0.5 bg-primary" />
            Método proprietário 30/30
          </div>
          <h2 className="font-display text-[clamp(2rem,5.2vw,4.8rem)] tracking-wide leading-[0.95] uppercase max-w-[1000px]">
            30 dias para estruturar.{" "}
            <span className="text-primary">30 dias para escalar.</span>{" "}
            60 dias para crescer.
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg mt-6 max-w-[680px] leading-relaxed">
            Uma metodologia proprietária desenvolvida para transformar negócios
            esportivos em operações mais previsíveis, organizadas e escaláveis.
          </p>
        </FadeIn>

        <div className="mt-14 sm:mt-20 grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8 relative">
          {/* connector */}
          <div className="hidden lg:block absolute top-[140px] left-1/2 -translate-x-1/2 z-0">
            <div className="w-16 h-px bg-primary/40" />
          </div>

          {phases.map((phase, i) => (
            <FadeIn key={phase.number} delay={i * 120}>
              <div className="relative bg-card border border-border rounded-xl p-7 sm:p-9 h-full hover:border-primary/50 transition-colors">
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <p className="text-[0.65rem] font-bold tracking-[4px] uppercase text-primary mb-2">
                      Fase {phase.number}
                    </p>
                    <h3 className="font-display text-4xl sm:text-5xl tracking-wide uppercase">
                      {phase.title}
                    </h3>
                    <p className="text-xs font-bold tracking-[3px] uppercase text-muted-foreground mt-2">
                      {phase.duration}
                    </p>
                  </div>
                  <span className="font-display text-6xl sm:text-7xl text-primary/15 leading-none">
                    {phase.number}
                  </span>
                </div>

                <p className="text-foreground/85 text-sm sm:text-base mb-6 border-l-2 border-primary pl-4">
                  {phase.objective}
                </p>

                <ul className="flex flex-col gap-2.5">
                  {phase.pillars.map((p) => (
                    <li
                      key={p}
                      className="flex items-start gap-3 text-sm sm:text-[0.95rem] text-foreground/80"
                    >
                      <span className="text-primary font-black mt-0.5">→</span>
                      {p}
                    </li>
                  ))}
                </ul>
              </div>
            </FadeIn>
          ))}
        </div>

        <FadeIn delay={300}>
          <div className="mt-12 sm:mt-16 flex flex-wrap items-center justify-center gap-3 sm:gap-5 text-xs sm:text-sm font-bold tracking-[3px] uppercase text-foreground/70">
            <span>Estruturar</span>
            <span className="text-primary">→</span>
            <span>Validar</span>
            <span className="text-primary">→</span>
            <span>Otimizar</span>
            <span className="text-primary">→</span>
            <span className="text-primary">Escalar</span>
          </div>
        </FadeIn>
      </div>
    </section>
  );
};

export default MethodTimeline;
