import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { ArrowRight, ArrowLeft, CheckCircle2 } from "lucide-react";
import FadeIn from "./FadeIn";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { calculateLeadScore } from "@/lib/leadScoring";

const WHATSAPP_NUMBER = "5582991050603";

const businessOptions = [
  { value: "academia", label: "Academia" },
  { value: "box", label: "Box" },
  { value: "estudio", label: "Estúdio" },
  { value: "escolinha", label: "Escolinha esportiva" },
  { value: "lutas", label: "Lutas" },
  { value: "beach_tennis", label: "Beach tennis" },
  { value: "outro", label: "Outro" },
];

const audienceOptions = [
  { value: "lt_50", label: "Menos de 50" },
  { value: "50_100", label: "50 a 100" },
  { value: "100_200", label: "100 a 200" },
  { value: "200_500", label: "200 a 500" },
  { value: "gt_500", label: "Mais de 500" },
];

const revenueOptions = [
  { value: "lt_10k", label: "Até R$10 mil" },
  { value: "10_25k", label: "R$10 mil a R$25 mil" },
  { value: "25_50k", label: "R$25 mil a R$50 mil" },
  { value: "50_100k", label: "R$50 mil a R$100 mil" },
  { value: "gt_100k", label: "Acima de R$100 mil" },
];

const challengeOptions = [
  { value: "novos_alunos", label: "Conseguir novos alunos" },
  { value: "indicacao", label: "Dependência de indicação" },
  { value: "autoridade", label: "Baixa autoridade" },
  { value: "retencao", label: "Baixa retenção" },
  { value: "previsibilidade", label: "Pouca previsibilidade" },
  { value: "outro", label: "Outro" },
];

const marketingOptions = [
  { value: "nunca", label: "Nunca investi" },
  { value: "ja_investi", label: "Já investi antes" },
  { value: "atualmente", label: "Invisto atualmente" },
];

const adsOptions = [
  { value: "zero", label: "R$0" },
  { value: "lt_500", label: "Até R$500" },
  { value: "500_1500", label: "R$500 a R$1.500" },
  { value: "1500_3000", label: "R$1.500 a R$3.000" },
  { value: "gt_3000", label: "Acima de R$3.000" },
];

const goalOptions = [
  { value: "aumentar_alunos", label: "Aumentar alunos" },
  { value: "lotar_turmas", label: "Lotar turmas" },
  { value: "gerar_leads", label: "Gerar mais leads" },
  { value: "marca", label: "Fortalecer a marca" },
  { value: "previsibilidade", label: "Crescer de forma previsível" },
];

const step1Schema = z.object({
  name: z.string().trim().min(2, "Nome muito curto").max(80),
  phone: z
    .string()
    .trim()
    .min(10, "WhatsApp válido com DDD")
    .max(20)
    .regex(/^[0-9()\-\s+]+$/, "Apenas números e símbolos"),
  instagram: z.string().trim().max(50).optional().or(z.literal("")),
  business_type: z.string().min(2, "Selecione").max(40),
  audience_size: z.string().min(2, "Selecione").max(20),
});

const step2Schema = z.object({
  revenue_range: z.string().min(2, "Selecione").max(20),
  main_challenge: z.string().min(2, "Selecione").max(40),
  marketing_investment: z.string().min(2, "Selecione").max(20),
  ads_budget: z.string().min(2, "Selecione").max(20),
  goal_90d: z.string().min(2, "Selecione").max(40),
});

const labelClass =
  "text-[0.65rem] font-bold tracking-[3px] uppercase text-muted-foreground mb-2 block";
const errClass = "text-destructive text-xs mt-1.5";

interface ApplicationFormProps {
  embedded?: boolean;
}

const ApplicationForm = ({ embedded = false }: ApplicationFormProps) => {
  const [step, setStep] = useState<1 | 2>(1);
  const [done, setDone] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Step 1
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [instagram, setInstagram] = useState("");
  const [businessType, setBusinessType] = useState("");
  const [audienceSize, setAudienceSize] = useState("");

  // Step 2
  const [revenueRange, setRevenueRange] = useState("");
  const [mainChallenge, setMainChallenge] = useState("");
  const [marketingInvestment, setMarketingInvestment] = useState("");
  const [adsBudget, setAdsBudget] = useState("");
  const [goal90d, setGoal90d] = useState("");

  const collectErrors = (issues: z.ZodIssue[]) => {
    const e: Record<string, string> = {};
    issues.forEach((i) => {
      const k = i.path[0] as string;
      if (!e[k]) e[k] = i.message;
    });
    return e;
  };

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});
    const parsed = step1Schema.safeParse({
      name,
      phone,
      instagram,
      business_type: businessType,
      audience_size: audienceSize,
    });
    if (!parsed.success) {
      setErrors(collectErrors(parsed.error.issues));
      return;
    }
    setStep(2);
    window.scrollTo({ top: document.getElementById("aplicacao")?.offsetTop ?? 0, behavior: "smooth" });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});
    const parsed = step2Schema.safeParse({
      revenue_range: revenueRange,
      main_challenge: mainChallenge,
      marketing_investment: marketingInvestment,
      ads_budget: adsBudget,
      goal_90d: goal90d,
    });
    if (!parsed.success) {
      setErrors(collectErrors(parsed.error.issues));
      return;
    }

    const scoring = calculateLeadScore({
      audience_size: audienceSize,
      revenue_range: revenueRange,
      marketing_investment: marketingInvestment,
      ads_budget: adsBudget,
      goal_90d: goal90d,
    });

    const normalizedInstagram = instagram.trim().replace(/^@+/, "");

    setLoading(true);
    const { error } = await supabase.from("leads").insert({
      name: name.trim(),
      phone: phone.trim(),
      instagram: normalizedInstagram || null,
      business_type: businessType,
      audience_size: audienceSize,
      revenue_range: revenueRange,
      main_challenge: mainChallenge,
      marketing_investment: marketingInvestment,
      ads_budget: adsBudget,
      goal_90d: goal90d,
      source: "landing",
      score: scoring.score,
      temperature: scoring.temperature,
    });
    setLoading(false);

    if (error) {
      toast.error("Não foi possível enviar agora. Tente novamente em instantes.");
      return;
    }

    setDone(true);

    const businessLabel =
      businessOptions.find((b) => b.value === businessType)?.label || businessType;
    const message = `Olá, sou ${name}. Acabei de enviar minha aplicação para o Diagnóstico Estratégico da Vura. Tenho um(a) ${businessLabel}.`;
    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const goBack = () => {
    setErrors({});
    setStep(1);
  };

  if (done) {
    const doneCard = (
      <div className="bg-card border border-primary/40 rounded-xl p-10 sm:p-14 text-center">
        <div className="w-16 h-16 mx-auto rounded-xl bg-primary/15 border border-primary/40 flex items-center justify-center mb-6">
          <CheckCircle2 className="w-7 h-7 text-primary" />
        </div>
        <p className="text-[0.65rem] font-bold tracking-[4px] uppercase text-primary mb-3">
          Aplicação recebida
        </p>
        <h3 className="font-display text-3xl sm:text-4xl tracking-wide uppercase leading-tight">
          Sua aplicação está em análise.
        </h3>
        <p className="text-muted-foreground text-sm sm:text-base mt-5 leading-relaxed">
          Um especialista da Vura avaliará seu perfil e entrará em contato em
          até 24 horas úteis pelo WhatsApp. Abrimos uma conversa pra você
          continuar agora se preferir.
        </p>
      </div>
    );

    if (embedded) return doneCard;

    return (
      <section
        id="aplicacao"
        className="py-20 sm:py-28 px-4 sm:px-6 md:px-12 bg-secondary border-t border-border/60"
      >
        <div className="container mx-auto max-w-[700px]">
          <FadeIn>{doneCard}</FadeIn>
        </div>
      </section>
    );
  }

  const formCard = (
    <div className={embedded ? "p-5 sm:p-9" : "bg-card border border-border rounded-xl p-5 sm:p-9"}>
              {/* Progress */}
              <div className="flex items-center justify-between mb-6">
                <p className="text-[0.65rem] font-bold tracking-[3px] uppercase text-muted-foreground">
                  Etapa {step} de 2
                </p>
                <p className="text-[0.65rem] font-bold tracking-[3px] uppercase text-primary">
                  {step === 1 ? "Identificação" : "Qualificação"}
                </p>
              </div>
              <div className="h-1 w-full bg-background rounded-full mb-8 overflow-hidden">
                <div
                  className="h-full bg-primary transition-all duration-500"
                  style={{ width: step === 1 ? "50%" : "100%" }}
                />
              </div>

              {step === 1 ? (
                <form onSubmit={handleNext} className="flex flex-col gap-4" noValidate>
                  <div>
                    <label className={labelClass}>Seu nome</label>
                    <Input
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      maxLength={80}
                      placeholder="Como prefere ser chamado(a)"
                      className="bg-background border-border focus-visible:ring-primary"
                    />
                    {errors.name && <p className={errClass}>{errors.name}</p>}
                  </div>

                  <div>
                    <label className={labelClass}>WhatsApp</label>
                    <Input
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      maxLength={20}
                      inputMode="tel"
                      placeholder="(82) 99105-0603"
                      className="bg-background border-border focus-visible:ring-primary"
                    />
                    {errors.phone && <p className={errClass}>{errors.phone}</p>}
                  </div>

                  <div>
                    <label className={labelClass}>Instagram do negócio</label>
                    <Input
                      value={instagram}
                      onChange={(e) => setInstagram(e.target.value)}
                      maxLength={50}
                      placeholder="@suaacademia"
                      className="bg-background border-border focus-visible:ring-primary"
                    />
                    {errors.instagram && <p className={errClass}>{errors.instagram}</p>}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className={labelClass}>Tipo de negócio</label>
                      <Select value={businessType} onValueChange={setBusinessType}>
                        <SelectTrigger className="bg-background border-border focus:ring-primary">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          {businessOptions.map((o) => (
                            <SelectItem key={o.value} value={o.value}>
                              {o.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.business_type && <p className={errClass}>{errors.business_type}</p>}
                    </div>
                    <div>
                      <label className={labelClass}>Alunos/clientes ativos</label>
                      <Select value={audienceSize} onValueChange={setAudienceSize}>
                        <SelectTrigger className="bg-background border-border focus:ring-primary">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          {audienceOptions.map((o) => (
                            <SelectItem key={o.value} value={o.value}>
                              {o.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.audience_size && <p className={errClass}>{errors.audience_size}</p>}
                    </div>
                  </div>

                  <Button
                    type="submit"
                    className="bg-primary hover:bg-primary-hover text-primary-foreground font-black text-xs sm:text-sm tracking-[2px] uppercase py-6 mt-3"
                  >
                    Continuar a aplicação
                    <ArrowRight className="ml-1 h-5 w-5" />
                  </Button>
                </form>
              ) : (
                <form onSubmit={handleSubmit} className="flex flex-col gap-4" noValidate>
                  <div>
                    <label className={labelClass}>Faturamento médio mensal</label>
                    <Select value={revenueRange} onValueChange={setRevenueRange}>
                      <SelectTrigger className="bg-background border-border focus:ring-primary">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {revenueOptions.map((o) => (
                          <SelectItem key={o.value} value={o.value}>
                            {o.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.revenue_range && <p className={errClass}>{errors.revenue_range}</p>}
                  </div>

                  <div>
                    <label className={labelClass}>Maior desafio hoje</label>
                    <Select value={mainChallenge} onValueChange={setMainChallenge}>
                      <SelectTrigger className="bg-background border-border focus:ring-primary">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {challengeOptions.map((o) => (
                          <SelectItem key={o.value} value={o.value}>
                            {o.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.main_challenge && <p className={errClass}>{errors.main_challenge}</p>}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className={labelClass}>Já investe em marketing?</label>
                      <Select value={marketingInvestment} onValueChange={setMarketingInvestment}>
                        <SelectTrigger className="bg-background border-border focus:ring-primary">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          {marketingOptions.map((o) => (
                            <SelectItem key={o.value} value={o.value}>
                              {o.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.marketing_investment && (
                        <p className={errClass}>{errors.marketing_investment}</p>
                      )}
                    </div>
                    <div>
                      <label className={labelClass}>Investimento em anúncios</label>
                      <Select value={adsBudget} onValueChange={setAdsBudget}>
                        <SelectTrigger className="bg-background border-border focus:ring-primary">
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          {adsOptions.map((o) => (
                            <SelectItem key={o.value} value={o.value}>
                              {o.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      {errors.ads_budget && <p className={errClass}>{errors.ads_budget}</p>}
                    </div>
                  </div>

                  <div>
                    <label className={labelClass}>Objetivo para os próximos 90 dias</label>
                    <Select value={goal90d} onValueChange={setGoal90d}>
                      <SelectTrigger className="bg-background border-border focus:ring-primary">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {goalOptions.map((o) => (
                          <SelectItem key={o.value} value={o.value}>
                            {o.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    {errors.goal_90d && <p className={errClass}>{errors.goal_90d}</p>}
                  </div>

                  <div className="flex flex-col sm:flex-row gap-3 mt-3">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={goBack}
                      className="border-border text-foreground font-bold text-xs sm:text-sm tracking-[2px] uppercase py-6 sm:w-auto"
                    >
                      <ArrowLeft className="mr-1 h-4 w-4" />
                      Voltar
                    </Button>
                    <Button
                      type="submit"
                      disabled={loading}
                      className="bg-primary hover:bg-primary-hover text-primary-foreground font-black text-xs sm:text-sm tracking-[2px] uppercase py-6 flex-1"
                    >
                      {loading ? "Enviando..." : "Enviar aplicação"}
                      {!loading && <ArrowRight className="ml-1 h-5 w-5" />}
                    </Button>
                  </div>

                  <p className="text-muted-foreground text-[0.65rem] text-center mt-1">
                    Seus dados são tratados com confidencialidade. Avaliação sem
                    compromisso.
                  </p>
                </form>
              )}
    </div>
  );

  if (embedded) return formCard;

  return (
    <section
      id="aplicacao"
      className="py-20 sm:py-28 px-4 sm:px-6 md:px-12 bg-secondary border-t border-border/60"
    >
      <div className="container mx-auto max-w-[1100px]">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_1.1fr] gap-10 lg:gap-16 items-start">
          <FadeIn>
            <div className="flex items-center gap-3 text-xs font-bold tracking-[4px] uppercase text-primary mb-5">
              <span className="w-8 h-0.5 bg-primary" />
              Aplicação estratégica
            </div>
            <h2 className="font-display text-[clamp(2rem,4.8vw,4.2rem)] tracking-wide leading-[0.95] uppercase">
              Aplique para o <span className="text-primary">Diagnóstico Estratégico.</span>
            </h2>
            <p className="text-muted-foreground text-sm sm:text-base mt-6 leading-relaxed max-w-[460px]">
              A Vura trabalha com um número limitado de operações por trimestre.
            </p>
          </FadeIn>
          <FadeIn delay={120}>{formCard}</FadeIn>
        </div>
      </div>
    </section>
  );
};

export default ApplicationForm;

