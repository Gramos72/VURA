import { Helmet } from "react-helmet-async";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import WhatsAppButton from "@/components/WhatsAppButton";
import { Target, Users, TrendingUp, Zap } from "lucide-react";

const About = () => {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Sobre a Vura — Agência de Marketing Esportivo</title>
        <meta name="description" content="Conheça a Vura: missão, time e diferenciais da agência especializada em marketing esportivo para academias e eventos." />
        <link rel="canonical" href="https://vura-agencia.lovable.app/sobre" />
        <meta property="og:title" content="Sobre a Vura — Agência de Marketing Esportivo" />
        <meta property="og:url" content="https://vura-agencia.lovable.app/sobre" />
      </Helmet>
      <Navbar />
      
      {/* Hero Sobre */}
      <section className="pt-32 pb-20 bg-gradient-hero">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <h1 className="text-5xl md:text-6xl font-extrabold text-foreground">
              Sobre a <span className="text-primary">Vura</span>
            </h1>
            <p className="text-2xl text-muted-foreground">
              Marketing esportivo que gera resultados reais
            </p>
          </div>
        </div>
      </section>

      {/* Missão */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto space-y-12">
            <div className="text-center space-y-6">
              <h2 className="text-4xl md:text-5xl font-bold text-foreground">
                Nossa <span className="text-primary">Missão</span>
              </h2>
              <p className="text-xl text-muted-foreground leading-relaxed">
                A Vura nasceu da necessidade de profissionalizar o marketing esportivo brasileiro. 
                Vimos academias, esportes e eventos esportivos com enorme potencial, 
                mas sem estratégias de marketing eficientes para crescer.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-12">
              <div className="space-y-4 p-6 rounded-lg bg-secondary/50">
                <Target className="h-12 w-12 text-primary" />
                <h3 className="text-2xl font-bold text-foreground">Nosso Foco</h3>
                <p className="text-muted-foreground">
                  Especialização exclusiva no mercado esportivo. Entendemos cada modalidade, 
                  cada público e cada desafio específico desse universo.
                </p>
              </div>

              <div className="space-y-4 p-6 rounded-lg bg-secondary/50">
                <Users className="h-12 w-12 text-primary" />
                <h3 className="text-2xl font-bold text-foreground">Nosso Time</h3>
                <p className="text-muted-foreground">
                  Profissionais apaixonados por esporte e marketing, com experiência 
                  comprovada em campanhas de alto desempenho no segmento fitness.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Posicionamento */}
      <section className="py-20 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto space-y-12">
            <div className="text-center space-y-6">
              <h2 className="text-4xl md:text-5xl font-bold text-foreground">
                O que nos <span className="text-primary">diferencia</span>
              </h2>
            </div>

            <div className="space-y-8">
              <div className="flex flex-col md:flex-row gap-6 items-start p-6 rounded-lg bg-background">
                <div className="flex-shrink-0">
                  <div className="h-16 w-16 rounded-full bg-primary/20 flex items-center justify-center">
                    <TrendingUp className="h-8 w-8 text-primary" />
                  </div>
                </div>
                <div className="space-y-2">
                  <h3 className="text-2xl font-bold text-foreground">Resultados mensuráveis</h3>
                  <p className="text-muted-foreground">
                    Não fazemos marketing por fazer. Cada ação é planejada, executada e medida. 
                    Trabalhamos com metas claras: número de alunos, custo por aquisição, ROI.
                  </p>
                </div>
              </div>

              <div className="flex flex-col md:flex-row gap-6 items-start p-6 rounded-lg bg-background">
                <div className="flex-shrink-0">
                  <div className="h-16 w-16 rounded-full bg-primary/20 flex items-center justify-center">
                    <Zap className="h-8 w-8 text-primary" />
                  </div>
                </div>
                <div className="space-y-2">
                  <h3 className="text-2xl font-bold text-foreground">Agilidade e otimização</h3>
                  <p className="text-muted-foreground">
                    Fazemos ajustes semanais nas campanhas. O mercado esportivo é dinâmico, 
                    e nossas estratégias acompanham esse ritmo para sempre entregar o melhor resultado.
                  </p>
                </div>
              </div>

              <div className="flex flex-col md:flex-row gap-6 items-start p-6 rounded-lg bg-background">
                <div className="flex-shrink-0">
                  <div className="h-16 w-16 rounded-full bg-primary/20 flex items-center justify-center">
                    <Target className="h-8 w-8 text-primary" />
                  </div>
                </div>
                <div className="space-y-2">
                  <h3 className="text-2xl font-bold text-foreground">Linguagem do esporte</h3>
                  <p className="text-muted-foreground">
                    Falamos a língua do seu público. Entendemos de periodização, treino funcional, 
                    alta intensidade, competições. Isso se reflete em campanhas mais autênticas e eficazes.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Slogan */}
      <section className="py-20 bg-gradient-primary">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <h2 className="text-4xl md:text-5xl font-extrabold text-foreground">
              Mais alunos. Mais inscritos.<br />
              <span className="text-background">Mais esporte.</span>
            </h2>
            <p className="text-xl text-foreground/90">
              Este é o nosso compromisso com cada cliente que confia na Vura.
            </p>
            <div className="pt-4">
              <WhatsAppButton 
                text="Vamos crescer juntos"
                size="lg"
                className="bg-background text-primary hover:bg-background/90 font-bold"
              />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default About;
