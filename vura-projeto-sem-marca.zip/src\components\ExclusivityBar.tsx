const ExclusivityBar = () => {
  return (
    <div className="fixed top-0 left-0 right-0 z-[60] bg-primary text-primary-foreground text-center py-2 px-3">
      <p className="text-[0.6rem] sm:text-xs font-bold tracking-[1.5px] sm:tracking-[3px] uppercase leading-tight">
        <span className="sm:hidden">Exclusivo para operações esportivas</span>
        <span className="hidden sm:inline">Exclusivo para operações esportivas que querem escalar com previsibilidade</span>
      </p>
    </div>
  );
};

export default ExclusivityBar;
