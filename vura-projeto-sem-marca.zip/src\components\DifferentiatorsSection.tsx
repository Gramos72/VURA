import FadeIn from "./FadeIn";
import { Target, Layers, Trophy, LineChart } from "lucide-react";

const items = [
  {
    icon: Target,
    title: "Operadora de crescimento",
    desc: "Não entregamos posts soltos. Operamos a aquisição, retenção e expansão do seu negócio esportivo como uma unidade integrada.",
  },
  {
    icon: Layers,
    title: "Metodologia proprietária 30/30",
    desc: "Um caminho validado em duas fases — Estruturar e Escalar — pensado especificamente para a realidade de operações esportivas.",
  },
  {
    icon: Trophy,
    title: "Foco exclusivo em esporte",
    desc: "Não atendemos qualquer nicho. Cada decisão é baseada em padrões reais de academias, boxes, estúdios e eventos esportivos.",
  },
  {
    icon: LineChart,
    title: "Performance, não entregáveis",
    desc: "Não vendemos pacotes de mídia. Trabalhamos por previsibilidade — alunos novos, matrículas e crescimento mensurável.",
  },
];

const DifferentiatorsSection = () => {
  return (
    <section
      id="diferenciais"
      className="py-20 sm:py-28 px-4 sm:px-6 md:px-12 bg-secondary border-t border-border/60"
    >
      <div className="container mx-auto max-w-[1200px]">
        <FadeIn>
          <div className="flex items-center gap-3 text-xs font-bold tracking-[4px] uppercase text-primary mb-5">
            <span className="w-8 h-0.5 bg-primary" />
            Por que VURA é diferente
          </div>
          <h2 className="font-display text-[clamp(2rem,5vw,4.5rem)] tracking-wide leading-[0.95] uppercase max-w-[900px]">
            Não somos uma agência.{" "}
            <span className="text-primary">Somos uma operadora de crescimento.</span>
          </h2>
        </FadeIn>

        <div className="mt-12 sm:mt-16 grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6">
          {items.map((item, i) => (
            <FadeIn key={item.title} delay={i * 100}>
              <div className="bg-card border border-border rounded-xl p-7 sm:p-8 h-full hover:border-primary/50 transition-colors group">
                <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center mb-5 group-hover:bg-primary/20 transition-colors">
                  <item.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-display text-2xl sm:text-3xl tracking-wide uppercase mb-3">
                  {item.title}
                </h3>
                <p className="text-muted-foreground text-sm sm:text-base leading-relaxed">
                  {item.desc}
                </p>
              </div>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
};

export default DifferentiatorsSection;
