import FadeIn from "./FadeIn";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    q: "Como funciona o investimento no método 30/30?",
    a: "Trabalhamos com pacotes estruturados por porte de operação. Após o Diagnóstico Estratégico apresentamos a proposta com escopo, metas e investimento alinhados ao seu objetivo de crescimento.",
  },
  {
    q: "O método se aplica a operações pequenas ou apenas a grandes?",
    a: "O 30/30 é aplicado em operações a partir de 50 clientes ativos. Já estruturamos negócios com 60 alunos e também unidades com mais de 800 — o que muda é a profundidade de cada fase, não a entrega.",
  },
  {
    q: "Quando os primeiros resultados aparecem?",
    a: "Os primeiros leads qualificados costumam chegar nos 15 dias iniciais após a ativação. Resultado consistente e previsível: a partir do encerramento do ciclo de 60 dias do método.",
  },
  {
    q: "Existe contrato de fidelidade?",
    a: "Não trabalhamos com fidelidade longa. O ciclo de 60 dias é fechado por escopo e a continuidade acontece por performance entregue.",
  },
  {
    q: "Atendem operações fora da minha região?",
    a: "Sim. Operamos com negócios esportivos em todo o Brasil de forma totalmente remota — reuniões por vídeo, relatórios semanais e canal direto com o time.",
  },
  {
    q: "O que acontece após enviar a aplicação?",
    a: "Sua aplicação entra em análise. Em até 24 horas úteis um especialista da Vura faz contato pelo WhatsApp para conduzir o Diagnóstico Estratégico e avaliar fit com o método.",
  },
];

const FaqSection = () => {
  return (
    <section id="faq" className="py-20 sm:py-28 px-4 sm:px-6 md:px-12 bg-background border-t border-border/60">
      <div className="container mx-auto max-w-[900px]">
        <FadeIn>
          <div className="flex items-center gap-3 text-xs font-bold tracking-[4px] uppercase text-primary mb-5">
            <span className="w-8 h-0.5 bg-primary" />
            Perguntas frequentes
          </div>
          <h2 className="font-display text-[clamp(2rem,5vw,4.5rem)] tracking-wide leading-[0.95] uppercase max-w-[800px] mb-10 sm:mb-14">
            Antes da aplicação, <span className="text-primary">o que você precisa saber.</span>
          </h2>
        </FadeIn>

        <FadeIn delay={150}>
          <Accordion type="single" collapsible className="flex flex-col gap-3">
            {faqs.map((f, i) => (
              <AccordionItem
                key={i}
                value={`item-${i}`}
                className="bg-card border border-border rounded-xl px-5 sm:px-7 data-[state=open]:border-primary/50 transition-colors"
              >
                <AccordionTrigger className="font-display text-lg sm:text-xl tracking-wide text-left hover:no-underline py-5 sm:py-6 [&[data-state=open]>svg]:text-primary">
                  {f.q}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-sm sm:text-base leading-relaxed pb-5 sm:pb-6">
                  {f.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </FadeIn>
      </div>
    </section>
  );
};

export default FaqSection;
