export type Temperature = "cold" | "warm" | "hot";

interface ScoringInput {
  audience_size: string;
  revenue_range: string;
  marketing_investment: string;
  ads_budget: string;
  goal_90d: string;
}

export function calculateLeadScore(input: ScoringInput): {
  score: number;
  temperature: Temperature;
} {
  let score = 0;

  // +3 if more than 100 active students
  if (["100_200", "200_500", "gt_500"].includes(input.audience_size)) {
    score += 3;
  }

  // +3 if revenue above R$25k
  if (["25_50k", "50_100k", "gt_100k"].includes(input.revenue_range)) {
    score += 3;
  }

  // +2 if currently investing in marketing
  if (input.marketing_investment === "atualmente") {
    score += 2;
  }

  // +2 if any ads budget
  if (
    ["lt_500", "500_1500", "1500_3000", "gt_3000"].includes(input.ads_budget)
  ) {
    score += 2;
  }

  // +2 if goal = predictable growth
  if (input.goal_90d === "previsibilidade") {
    score += 2;
  }

  let temperature: Temperature = "cold";
  if (score >= 9) temperature = "hot";
  else if (score >= 5) temperature = "warm";

  return { score, temperature };
}
