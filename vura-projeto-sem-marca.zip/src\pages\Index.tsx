import { Helmet } from "react-helmet-async";
import ExclusivityBar from "@/components/ExclusivityBar";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import SocialProofBar from "@/components/SocialProofBar";
import ApplicationSection from "@/components/ApplicationSection";
import GrowthSimulator from "@/components/GrowthSimulator";
import MethodTimeline from "@/components/MethodTimeline";
import ManifestoDivider from "@/components/ManifestoDivider";
import DifferentiatorsSection from "@/components/DifferentiatorsSection";
import ResultsSection from "@/components/ResultsSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import FaqSection from "@/components/FaqSection";
import CtaFinal from "@/components/CtaFinal";
import Footer from "@/components/Footer";
import WhatsAppFloat from "@/components/WhatsAppFloat";


const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Helmet>
        <title>Vura — Crescimento para Negócios Esportivos</title>
        <meta
          name="description"
          content="Método 30/30: 60 dias para estruturar e escalar academias, boxes, estúdios e operações esportivas com previsibilidade."
        />
        <link rel="canonical" href="https://vura-agencia.lovable.app/" />
        <meta property="og:title" content="Vura — Crescimento para Negócios Esportivos" />
        <meta property="og:url" content="https://vura-agencia.lovable.app/" />
      </Helmet>
      <ExclusivityBar />
      <Navbar />
      <Hero />
      <SocialProofBar />
      <GrowthSimulator />
      <ApplicationSection />
      <MethodTimeline />
      <ManifestoDivider />
      <DifferentiatorsSection />
      <ResultsSection />
      <TestimonialsSection />
      <FaqSection />
      <CtaFinal />
      <Footer />
      <WhatsAppFloat />

    </div>
  );
};

export default Index;
