import FadeIn from "./FadeIn";

const niches = [
  { icon: "🏋️", label: "Academias de musculação" },
  { icon: "🔥", label: "Boxes de CrossFit" },
  { icon: "🧘", label: "Estúdios de Pilates" },
  { icon: "⚽", label: "Escolinhas esportivas" },
  { icon: "🥊", label: "Academias de lutas" },
  { icon: "🎾", label: "Beach Tennis" },
  { icon: "🥋", label: "Jiu-Jitsu" },
  { icon: "🏄", label: "Surf" },
  { icon: "🏆", label: "Eventos esportivos" },
  { icon: "🤸", label: "Personal trainers" },
  { icon: "❤️", label: "Projetos sociais" },
];

const NichesSection = () => {
  return (
    <section className="py-24 px-6 md:px-12 bg-background">
      <div className="container mx-auto">
      <FadeIn>
        <div className="flex items-center gap-3 text-xs font-bold tracking-[4px] uppercase text-primary mb-5">
          <span className="w-8 h-0.5 bg-primary" />
          Para quem é
        </div>
        <h2 className="font-display text-[clamp(2.8rem,5vw,5rem)] tracking-wide leading-none uppercase max-w-[700px]">
          Feito para negócios <span className="text-primary">do esporte.</span>
        </h2>
      </FadeIn>

        <div className="flex flex-wrap gap-3 mt-12">
          {niches.map((n, i) => (
            <div
              key={i}
              className="flex items-center gap-2.5 bg-card border border-border px-6 py-3.5 font-bold text-sm hover:border-primary hover:text-primary hover:bg-primary/5 transition-all cursor-default"
            >
              <span className="text-xl">{n.icon}</span>
              {n.label}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default NichesSection;
