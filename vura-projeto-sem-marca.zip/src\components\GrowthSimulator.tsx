import { useState, useMemo } from "react";
import FadeIn from "./FadeIn";
import { TrendingUp, Calculator } from "lucide-react";

const formatBRL = (n: number) =>
  n.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
    maximumFractionDigits: 0,
  });

const GrowthSimulator = () => {
  const [ticket, setTicket] = useState(180);
  const [novos, setNovos] = useState(50);

  const { mensal, anual } = useMemo(() => {
    const mensal = ticket * novos;
    return { mensal, anual: mensal * 12 };
  }, [ticket, novos]);

  return (
    <section
      id="simulador"
      className="py-16 sm:py-24 px-4 sm:px-6 md:px-12 bg-background border-t border-border/60"
    >
      <div className="container mx-auto max-w-[1200px]">
        <FadeIn>
          <div className="flex items-center gap-3 text-[0.65rem] sm:text-xs font-bold tracking-[3px] sm:tracking-[4px] uppercase text-primary mb-4 sm:mb-5">
            <span className="w-8 h-0.5 bg-primary" />
            Simulador de crescimento
          </div>
          <h2 className="font-display text-[clamp(1.75rem,4.6vw,4rem)] tracking-wide leading-[0.95] uppercase max-w-[900px]">
            Quanto sua operação pode{" "}
            <span className="text-primary">faturar a mais</span> com a Vura?
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg max-w-[680px] mt-5 leading-relaxed">
            Ajuste os números abaixo de acordo com a sua realidade e veja o
            impacto direto no seu faturamento.
          </p>
        </FadeIn>

        <FadeIn delay={120}>
          <div className="mt-10 sm:mt-14 grid grid-cols-1 lg:grid-cols-[1fr_1fr] gap-6 lg:gap-8">
            {/* Inputs */}
            <div className="bg-card border border-border rounded-xl p-6 sm:p-9">
              <div className="flex items-center gap-3 mb-8">
                <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/30 flex items-center justify-center">
                  <Calculator className="w-5 h-5 text-primary" />
                </div>
                <span className="font-display text-xl sm:text-2xl tracking-wide uppercase">
                  Seus números
                </span>
              </div>

              {/* Ticket */}
              <div className="mb-8">
                <div className="flex items-baseline justify-between mb-3">
                  <label
                    htmlFor="ticket"
                    className="text-xs font-bold uppercase tracking-[2px] text-muted-foreground"
                  >
                    Ticket médio mensal
                  </label>
                  <span className="font-display text-2xl sm:text-3xl text-primary tracking-wide">
                    {formatBRL(ticket)}
                  </span>
                </div>
                <input
                  id="ticket"
                  type="range"
                  min={80}
                  max={800}
                  step={10}
                  value={ticket}
                  onChange={(e) => setTicket(Number(e.target.value))}
                  className="w-full accent-primary cursor-pointer"
                />
                <div className="flex justify-between text-[0.65rem] uppercase tracking-wider text-muted-foreground mt-2">
                  <span>R$ 80</span>
                  <span>R$ 800</span>
                </div>
              </div>

              {/* Novos alunos */}
              <div>
                <div className="flex items-baseline justify-between mb-3">
                  <label
                    htmlFor="novos"
                    className="text-xs font-bold uppercase tracking-[2px] text-muted-foreground"
                  >
                    Novos alunos/clientes por mês
                  </label>
                  <span className="font-display text-2xl sm:text-3xl text-primary tracking-wide">
                    +{novos}
                  </span>
                </div>
                <input
                  id="novos"
                  type="range"
                  min={5}
                  max={200}
                  step={5}
                  value={novos}
                  onChange={(e) => setNovos(Number(e.target.value))}
                  className="w-full accent-primary cursor-pointer"
                />
                <div className="flex justify-between text-[0.65rem] uppercase tracking-wider text-muted-foreground mt-2">
                  <span>5</span>
                  <span>200</span>
                </div>
              </div>
            </div>

            {/* Output */}
            <div className="rounded-xl border border-primary/40 bg-gradient-to-br from-primary/15 via-card to-card p-6 sm:p-9 shadow-[0_0_60px_-15px_hsl(241_72%_50%/0.5)] flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-3 mb-8">
                  <div className="w-10 h-10 rounded-xl bg-primary border border-primary flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 text-primary-foreground" />
                  </div>
                  <span className="font-display text-xl sm:text-2xl tracking-wide uppercase">
                    Projeção de receita
                  </span>
                </div>

                <div className="mb-8">
                  <p className="text-[0.65rem] font-bold uppercase tracking-[3px] text-muted-foreground mb-2">
                    Faturamento adicional mensal
                  </p>
                  <p className="font-display text-4xl sm:text-6xl text-primary tracking-wide leading-none">
                    {formatBRL(mensal)}
                  </p>
                </div>

                <div className="pt-6 border-t border-border">
                  <p className="text-[0.65rem] font-bold uppercase tracking-[3px] text-muted-foreground mb-2">
                    Projeção anualizada
                  </p>
                  <p className="font-display text-3xl sm:text-5xl tracking-wide leading-none">
                    {formatBRL(anual)}
                  </p>
                </div>
              </div>

              <a
                href="#aplicacao"
                className="mt-8 inline-flex items-center justify-center gap-2 rounded-xl bg-primary text-primary-foreground font-bold uppercase tracking-[2px] text-sm py-4 px-6 hover:bg-primary/90 transition-colors animate-pulse-glow"
              >
                Quero esses resultados
                <TrendingUp className="w-4 h-4" />
              </a>
            </div>
          </div>

          <p className="mt-8 text-center text-[0.65rem] font-bold tracking-[3px] uppercase text-muted-foreground">
            Estimativa baseada nos seus números · Não é promessa de resultado
          </p>
        </FadeIn>
      </div>
    </section>
  );
};

export default GrowthSimulator;
