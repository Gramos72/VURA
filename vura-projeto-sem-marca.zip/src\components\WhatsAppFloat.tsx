const WhatsAppFloat = () => {
  const phoneNumber = "5582991050603";
  const message = encodeURIComponent("Olá, gostaria de saber mais sobre os serviços da Vura!");
  const url = `https://wa.me/${phoneNumber}?text=${message}`;

  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-4 right-4 sm:bottom-8 sm:right-8 z-[200] flex items-center gap-2 sm:gap-3 bg-[#25D366] text-white font-black text-[0.7rem] sm:text-xs tracking-wide uppercase px-4 sm:px-5 py-3 sm:py-3.5 rounded-full shadow-[0_8px_32px_rgba(37,211,102,0.35)] hover:translate-y-[-4px] hover:shadow-[0_16px_40px_rgba(37,211,102,0.5)] transition-all animate-float"
    >
      💬 Falar agora
    </a>
  );
};

export default WhatsAppFloat;
