CREATE TABLE public.leads (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  business_type TEXT NOT NULL,
  source TEXT NOT NULL DEFAULT 'landing'
);

ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can insert leads"
  ON public.leads
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    char_length(name) BETWEEN 2 AND 80
    AND char_length(phone) BETWEEN 8 AND 20
    AND char_length(business_type) BETWEEN 2 AND 40
    AND char_length(source) BETWEEN 2 AND 40
  );