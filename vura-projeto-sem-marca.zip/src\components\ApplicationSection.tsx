import FadeIn from "./FadeIn";
import ApplicationForm from "./ApplicationForm";

const steps = [
  {
    n: "01",
    title: "Preencha o formulário",
    desc: "Envie suas informações de contato. Todos os seus dados estão seguros — cuidamos bem deles.",
  },
  {
    n: "02",
    title: "Diagnóstico estratégico",
    desc: "Nossa equipe analisa o momento real da sua operação esportiva antes de qualquer conversa comercial.",
  },
  {
    n: "03",
    title: "Plano de crescimento",
    desc: "Você recebe um plano sob medida pra estruturar e escalar seu negócio com previsibilidade.",
  },
];

const ApplicationSection = () => {
  return (
    <section
      id="aplicacao-bloco"
      className="py-16 sm:py-28 px-4 sm:px-6 md:px-12 bg-secondary border-t border-border/60"
    >
      <div className="container mx-auto max-w-[1200px]">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_1.05fr] gap-10 lg:gap-16 items-start">
          {/* LEFT: numbered steps */}
          <FadeIn>
            <div className="flex items-center gap-3 text-[0.65rem] sm:text-xs font-bold tracking-[3px] sm:tracking-[4px] uppercase text-primary mb-4 sm:mb-5">
              <span className="w-8 h-0.5 bg-primary" />
              Como funciona
            </div>
            <h2 className="font-display text-[clamp(1.75rem,4.6vw,4rem)] tracking-wide leading-[0.95] uppercase">
              Preencha o formulário para ter um{" "}
              <span className="text-primary">diagnóstico estratégico</span>{" "}
              montado pela Vura.
            </h2>

            <ul className="mt-8 sm:mt-14 flex flex-col">
              {steps.map((s, i) => (
                <li
                  key={s.n}
                  className={`flex gap-5 sm:gap-7 py-6 sm:py-7 ${
                    i < steps.length - 1 ? "border-b border-border" : ""
                  }`}
                >
                  <span className="font-display text-4xl sm:text-5xl text-primary leading-none tracking-wide shrink-0 w-14 sm:w-16">
                    {s.n}
                  </span>
                  <div>
                    <h3 className="font-display text-xl sm:text-2xl tracking-wide uppercase mb-2">
                      {s.title}
                    </h3>
                    <p className="text-muted-foreground text-sm sm:text-base leading-relaxed">
                      {s.desc}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          </FadeIn>

          {/* RIGHT: form card */}
          <FadeIn delay={120}>
            <div
              id="aplicacao"
              className="rounded-xl border border-primary/30 bg-card p-1 shadow-[0_0_60px_-15px_hsl(241_72%_50%/0.4)]"
            >
              <div className="rounded-[10px] bg-card">
                <ApplicationForm embedded />
              </div>
            </div>
          </FadeIn>
        </div>
      </div>
    </section>
  );
};

export default ApplicationSection;
