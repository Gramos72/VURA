export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      leads: {
        Row: {
          ads_budget: string | null
          audience_size: string | null
          business_type: string
          created_at: string
          goal_90d: string | null
          id: string
          instagram: string | null
          main_challenge: string | null
          marketing_investment: string | null
          name: string
          phone: string
          revenue_range: string | null
          score: number | null
          source: string
          temperature: string | null
        }
        Insert: {
          ads_budget?: string | null
          audience_size?: string | null
          business_type: string
          created_at?: string
          goal_90d?: string | null
          id?: string
          instagram?: string | null
          main_challenge?: string | null
          marketing_investment?: string | null
          name: string
          phone: string
          revenue_range?: string | null
          score?: number | null
          source?: string
          temperature?: string | null
        }
        Update: {
          ads_budget?: string | null
          audience_size?: string | null
          business_type?: string
          created_at?: string
          goal_90d?: string | null
          id?: string
          instagram?: string | null
          main_challenge?: string | null
          marketing_investment?: string | null
          name?: string
          phone?: string
          revenue_range?: string | null
          score?: number | null
          source?: string
          temperature?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      leads_pt: {
        Row: {
          "Alunos Ativos": string | null
          "Data de Cadastro": string | null
          "Faturamento Mensal": string | null
          ID: string | null
          Instagram: string | null
          "Investe em Marketing": string | null
          Nome: string | null
          "Objetivo em 90 dias": string | null
          "Orçamento de Anúncios": string | null
          Origem: string | null
          Pontuação: number | null
          "Principal Desafio": string | null
          Temperatura: string | null
          "Tipo de Negócio": string | null
          WhatsApp: string | null
        }
        Insert: {
          "Alunos Ativos"?: never
          "Data de Cadastro"?: never
          "Faturamento Mensal"?: never
          ID?: string | null
          Instagram?: string | null
          "Investe em Marketing"?: never
          Nome?: string | null
          "Objetivo em 90 dias"?: never
          "Orçamento de Anúncios"?: never
          Origem?: string | null
          Pontuação?: number | null
          "Principal Desafio"?: never
          Temperatura?: never
          "Tipo de Negócio"?: never
          WhatsApp?: string | null
        }
        Update: {
          "Alunos Ativos"?: never
          "Data de Cadastro"?: never
          "Faturamento Mensal"?: never
          ID?: string | null
          Instagram?: string | null
          "Investe em Marketing"?: never
          Nome?: string | null
          "Objetivo em 90 dias"?: never
          "Orçamento de Anúncios"?: never
          Origem?: string | null
          Pontuação?: number | null
          "Principal Desafio"?: never
          Temperatura?: never
          "Tipo de Negócio"?: never
          WhatsApp?: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
