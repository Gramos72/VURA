import FadeIn from "./FadeIn";

const services = [
  { icon: "🎯", title: "Tráfego Pago", desc: "Anúncios que trazem gente de verdade pra sua porta — não curtida de quem nunca vai pisar aí.", tag: "Google · Meta Ads" },
  { icon: "📱", title: "Social Media", desc: "A gente cuida do conteúdo pra você parar de se preocupar com o que postar.", tag: "Instagram · TikTok" },
  { icon: "⚡", title: "Branding", desc: "Sua marca vai parecer tão profissional quanto o serviço que você entrega.", tag: "Identidade · Posição" },
  { icon: "🧠", title: "Estratégia Digital", desc: "Chega de atirar pra todo lado. A gente monta o caminho e executa com você.", tag: "Funil · Planejamento" },
  { icon: "🏆", title: "Eventos Esportivos", desc: "Seu evento lotado, com inscrições antes mesmo de abrir as portas.", tag: "Eventos · Inscrições" },
  { icon: "📊", title: "Você vê tudo", desc: "Relatório semanal na sua mão. Sem enrolação, sem métrica de vaidade.", tag: "Relatório · ROI" },
];

const ServicesSection = () => {
  return (
    <section id="servicos" className="py-16 sm:py-24 px-4 sm:px-6 md:px-12 bg-secondary">
      <div className="container mx-auto">
        <FadeIn>
          <div className="flex items-center gap-3 text-xs font-bold tracking-[4px] uppercase text-primary mb-5">
            <span className="w-8 h-0.5 bg-primary" />
            O que fazemos
          </div>
          <h2 className="font-display text-[clamp(2.2rem,5vw,5rem)] tracking-wide leading-none uppercase max-w-[700px]">
            Tudo que você precisa, <span className="text-primary">num só lugar.</span>
          </h2>
        </FadeIn>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-[2px] bg-border mt-10 sm:mt-14">
          {services.map((s, i) => (
            <FadeIn key={i} staggerIndex={i} className="bg-card p-6 sm:p-10 group transition-colors hover:bg-card/80">
              <span className="text-2xl sm:text-3xl block mb-4 sm:mb-5 transition-transform group-hover:scale-110 group-hover:text-primary">
                {s.icon}
              </span>
              <h3 className="font-display text-xl sm:text-2xl tracking-wide mb-2 sm:mb-3">{s.title}</h3>
              <p className="text-muted-foreground text-xs sm:text-sm leading-relaxed">{s.desc}</p>
              <span className="inline-block mt-4 sm:mt-5 text-[0.65rem] sm:text-xs font-bold tracking-[2px] uppercase text-primary border border-primary/30 px-3 py-1">
                {s.tag}
              </span>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
