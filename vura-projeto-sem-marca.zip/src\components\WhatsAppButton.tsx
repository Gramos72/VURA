import { Button } from "@/components/ui/button";
import { MessageCircle } from "lucide-react";

interface WhatsAppButtonProps {
  text: string;
  message?: string;
  variant?: "default" | "hero" | "outline";
  size?: "default" | "lg" | "sm";
  className?: string;
}

const WhatsAppButton = ({ 
  text, 
  message = "Olá, gostaria de saber mais sobre os serviços da Vura!",
  variant = "default",
  size = "default",
  className = ""
}: WhatsAppButtonProps) => {
  const phoneNumber = "5582991050603";
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;

  return (
    <Button
      variant={variant}
      size={size}
      className={className}
      asChild
    >
      <a href={whatsappUrl} target="_blank" rel="noopener noreferrer">
        <MessageCircle className="mr-2 h-5 w-5" />
        {text}
      </a>
    </Button>
  );
};

export default WhatsAppButton;
