import { Card, CardContent } from "@/components/ui/card";

interface NicheCardProps {
  title: string;
  description: string;
  image: string;
}

const NicheCard = ({ title, description, image }: NicheCardProps) => {
  return (
    <Card className="group overflow-hidden hover:shadow-primary transition-all duration-300 border-border bg-card">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={image} 
          alt={title}
          className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent" />
      </div>
      <CardContent className="p-6">
        <h3 className="mb-2 text-xl font-bold text-foreground">{title}</h3>
        <p className="text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  );
};

export default NicheCard;
