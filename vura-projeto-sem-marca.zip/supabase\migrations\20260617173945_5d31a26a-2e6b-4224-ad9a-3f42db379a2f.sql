
ALTER TABLE public.leads
  ADD COLUMN IF NOT EXISTS instagram text,
  ADD COLUMN IF NOT EXISTS audience_size text,
  ADD COLUMN IF NOT EXISTS revenue_range text,
  ADD COLUMN IF NOT EXISTS main_challenge text,
  ADD COLUMN IF NOT EXISTS marketing_investment text,
  ADD COLUMN IF NOT EXISTS ads_budget text,
  ADD COLUMN IF NOT EXISTS goal_90d text,
  ADD COLUMN IF NOT EXISTS score integer,
  ADD COLUMN IF NOT EXISTS temperature text;

ALTER TABLE public.leads DROP CONSTRAINT IF EXISTS leads_business_type_check;
ALTER TABLE public.leads ADD CONSTRAINT leads_business_type_check
  CHECK (business_type IN ('academia','crossfit','box','estudio','escolinha','lutas','beach_tennis','personal','evento','outro'));

ALTER TABLE public.leads DROP CONSTRAINT IF EXISTS leads_audience_size_check;
ALTER TABLE public.leads ADD CONSTRAINT leads_audience_size_check
  CHECK (audience_size IS NULL OR audience_size IN ('lt_50','50_100','100_200','200_500','gt_500'));

ALTER TABLE public.leads DROP CONSTRAINT IF EXISTS leads_revenue_range_check;
ALTER TABLE public.leads ADD CONSTRAINT leads_revenue_range_check
  CHECK (revenue_range IS NULL OR revenue_range IN ('lt_10k','10_25k','25_50k','50_100k','gt_100k'));

ALTER TABLE public.leads DROP CONSTRAINT IF EXISTS leads_main_challenge_check;
ALTER TABLE public.leads ADD CONSTRAINT leads_main_challenge_check
  CHECK (main_challenge IS NULL OR main_challenge IN ('novos_alunos','indicacao','autoridade','retencao','previsibilidade','outro'));

ALTER TABLE public.leads DROP CONSTRAINT IF EXISTS leads_marketing_investment_check;
ALTER TABLE public.leads ADD CONSTRAINT leads_marketing_investment_check
  CHECK (marketing_investment IS NULL OR marketing_investment IN ('nunca','ja_investi','atualmente'));

ALTER TABLE public.leads DROP CONSTRAINT IF EXISTS leads_ads_budget_check;
ALTER TABLE public.leads ADD CONSTRAINT leads_ads_budget_check
  CHECK (ads_budget IS NULL OR ads_budget IN ('zero','lt_500','500_1500','1500_3000','gt_3000'));

ALTER TABLE public.leads DROP CONSTRAINT IF EXISTS leads_goal_90d_check;
ALTER TABLE public.leads ADD CONSTRAINT leads_goal_90d_check
  CHECK (goal_90d IS NULL OR goal_90d IN ('aumentar_alunos','lotar_turmas','gerar_leads','marca','previsibilidade'));

ALTER TABLE public.leads DROP CONSTRAINT IF EXISTS leads_temperature_check;
ALTER TABLE public.leads ADD CONSTRAINT leads_temperature_check
  CHECK (temperature IS NULL OR temperature IN ('cold','warm','hot'));

ALTER TABLE public.leads DROP CONSTRAINT IF EXISTS leads_instagram_length_check;
ALTER TABLE public.leads ADD CONSTRAINT leads_instagram_length_check
  CHECK (instagram IS NULL OR char_length(instagram) <= 50);
