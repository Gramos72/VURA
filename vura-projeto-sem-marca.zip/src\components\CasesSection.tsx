import FadeIn from "./FadeIn";
import { TrendingUp } from "lucide-react";

const cases = [
  {
    tag: "Academia",
    location: "Academia da região · Maceió/AL",
    title: "De 80 para 140 alunos em 45 dias",
    kpis: [
      { value: "+75%", label: "alunos ativos" },
      { value: "3.2x", label: "ROI em ads" },
      { value: "45d", label: "para virar a chave" },
    ],
    story:
      "Estrutura travada, anúncios sem rumo e quase zero conteúdo. Reposicionamos a marca, ativamos tráfego segmentado e criamos um funil simples no WhatsApp. Em 45 dias, lotação recorde.",
    progress: 75,
  },
  {
    tag: "Box de CrossFit",
    location: "Box CrossFit · Recife/PE",
    title: "3x mais leads qualificados em 60 dias",
    kpis: [
      { value: "3x", label: "leads/mês" },
      { value: "−40%", label: "custo por lead" },
      { value: "92%", label: "show-up na aula" },
    ],
    story:
      "Instagram bonito, mas sem leads. Reescrevemos a estratégia de conteúdo, estruturamos campanhas de aula experimental e implantamos automação no atendimento. Agenda lotada no segundo mês.",
    progress: 88,
  },
  {
    tag: "Evento Esportivo",
    location: "Evento Esportivo · Nordeste",
    title: "Evento lotado em 14 dias",
    kpis: [
      { value: "100%", label: "inscrições" },
      { value: "14d", label: "campanha ativa" },
      { value: "5.8x", label: "ROAS" },
    ],
    story:
      "Sem audiência, sem patrocínio e com prazo apertado. Construímos identidade do evento, anúncios com prova social e parcerias estratégicas. Lotamos em duas semanas e geramos lista de espera.",
    progress: 100,
  },
];

const CasesSection = () => {
  return (
    <section id="cases" className="py-16 sm:py-24 px-4 sm:px-6 md:px-12 bg-background">
      <div className="container mx-auto">
        <FadeIn>
          <div className="flex items-center gap-3 text-xs font-bold tracking-[4px] uppercase text-primary mb-5">
            <span className="w-8 h-0.5 bg-primary" />
            Cases reais
          </div>
          <h2 className="font-display text-[clamp(2rem,5vw,4.5rem)] tracking-wide leading-none uppercase max-w-[800px]">
            Resultado <span className="text-primary">com nome e número.</span>
          </h2>
          <p className="text-muted-foreground text-sm sm:text-base max-w-[600px] mt-4">
            Selecionamos três histórias que mostram o método rodando. Sem foto bonita: só números, prazo e o que mudou.
          </p>
        </FadeIn>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6 mt-10 sm:mt-14">
          {cases.map((c, i) => (
            <FadeIn key={i} staggerIndex={i}>
              <article className="bg-card border border-border rounded-xl p-6 sm:p-8 h-full flex flex-col hover:border-primary/50 transition-colors">
                <div className="flex items-center justify-between mb-5">
                  <span className="text-[0.65rem] font-bold tracking-[3px] uppercase text-primary border border-primary/30 px-3 py-1 rounded-full">
                    {c.tag}
                  </span>
                  <TrendingUp className="h-4 w-4 text-primary" />
                </div>

                <h3 className="font-display text-2xl sm:text-3xl tracking-wide leading-tight mb-2">
                  {c.title}
                </h3>
                <p className="text-muted-foreground text-xs uppercase tracking-wider mb-6">
                  {c.location}
                </p>

                <div className="grid grid-cols-3 gap-2 mb-6 pb-6 border-b border-border">
                  {c.kpis.map((kpi, j) => (
                    <div key={j}>
                      <div className="font-display text-2xl sm:text-3xl text-primary tracking-wide leading-none">
                        {kpi.value}
                      </div>
                      <div className="text-[0.6rem] sm:text-[0.65rem] text-muted-foreground uppercase tracking-wider mt-1.5">
                        {kpi.label}
                      </div>
                    </div>
                  ))}
                </div>

                <p className="text-foreground/80 text-sm leading-relaxed mb-6 flex-1">
                  {c.story}
                </p>

                <div>
                  <div className="flex items-center justify-between text-[0.65rem] uppercase tracking-[2px] text-muted-foreground mb-2">
                    <span>Progresso</span>
                    <span className="text-primary font-bold">{c.progress}%</span>
                  </div>
                  <div className="h-1.5 bg-border rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full transition-all duration-1000"
                      style={{ width: `${c.progress}%` }}
                    />
                  </div>
                </div>
              </article>
            </FadeIn>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CasesSection;
