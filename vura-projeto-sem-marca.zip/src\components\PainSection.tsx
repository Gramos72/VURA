import WhatsAppButton from "./WhatsAppButton";
import FadeIn from "./FadeIn";

const pains = [
  { icon: "📉", title: "Meses sem alunos novos", desc: "Você depende só de indicação e torce pra alguém aparecer. Não tem controle nenhum." },
  { icon: "📲", title: "Posta todo dia e ninguém aparece", desc: "Gasta tempo criando conteúdo, mas o Instagram parece invisível." },
  { icon: "💸", title: "Já jogou dinheiro em anúncio", desc: "Pagou tráfego, não veio ninguém. E ficou sem saber o que deu errado." },
  { icon: "🧠", title: "Faz tudo sozinho, sem direção", desc: "Treina aluno, cuida do caixa, posta no Insta... e o marketing fica por último." },
  { icon: "👻", title: "O concorrente cresce e você não", desc: "Ele tem menos estrutura, mas aparece mais. Dói, mas é real." },
];

const PainSection = () => {
  return (
    <section className="py-16 sm:py-24 px-4 sm:px-6 md:px-12 bg-secondary">
      <div className="container mx-auto">
        <FadeIn>
          <div className="flex items-center gap-3 text-xs font-bold tracking-[4px] uppercase text-primary mb-5">
            <span className="w-8 h-0.5 bg-primary" />
            Isso soa familiar?
          </div>
          <h2 className="font-display text-[clamp(2.2rem,5vw,5rem)] tracking-wide leading-none uppercase max-w-[700px]">
            Se você vive isso, <span className="text-primary">não é culpa sua.</span>
          </h2>
        </FadeIn>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-14 mt-10 sm:mt-14 items-start">
          <ul className="flex flex-col gap-3 sm:gap-4">
            {pains.map((p, i) => (
              <li
                key={i}
                className="flex items-start gap-3 sm:gap-4 p-4 sm:p-5 bg-card border-l-[3px] border-border hover:border-l-primary transition-colors rounded-xl"
              >
                <span className="text-xl sm:text-2xl flex-shrink-0 mt-0.5">{p.icon}</span>
                <div>
                  <strong className="block font-black mb-0.5 text-sm sm:text-base">{p.title}</strong>
                  <span className="text-muted-foreground text-xs sm:text-sm">{p.desc}</span>
                </div>
              </li>
            ))}
          </ul>

          <div className="bg-card border border-border p-6 sm:p-12 relative overflow-hidden rounded-xl">
            <div className="absolute top-0 left-0 right-0 h-[3px] bg-primary" />
            <blockquote className="font-display text-[1.8rem] sm:text-[2.4rem] tracking-wide leading-[1.1] mb-4 sm:mb-6">
              "Você não precisa trabalhar mais. Precisa de alguém que <span className="text-primary">traga resultado.</span>"
            </blockquote>
            <p className="text-muted-foreground text-xs sm:text-sm leading-relaxed">
              Quem vive o dia a dia de uma academia sabe: sobra dedicação, mas falta tempo pra cuidar do marketing direito. E quando tenta sozinho, o resultado não vem. A gente existe pra resolver isso.
            </p>
            <div className="mt-6 sm:mt-8">
              <WhatsAppButton
                text="Diagnóstico gratuito →"
                variant="outline"
                className="border-border text-foreground hover:border-primary hover:text-primary font-bold text-xs sm:text-sm tracking-[2px] uppercase px-6 sm:px-8 py-3 sm:py-4 w-full sm:w-auto"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PainSection;
