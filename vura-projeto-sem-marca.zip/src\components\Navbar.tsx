import { Link } from "react-router-dom";
import { useState } from "react";
import { Menu, X } from "lucide-react";

const navLinks = [
  { label: "Método", href: "#metodo" },
  { label: "Diferenciais", href: "#diferenciais" },
  { label: "Resultados", href: "#resultados" },
  { label: "FAQ", href: "#faq" },
];

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-8 sm:top-10 left-0 right-0 z-50 flex items-center justify-between px-4 sm:px-6 md:px-12 py-3 sm:py-5 bg-background/90 backdrop-blur-sm border-b border-border">
      <Link to="/" className="font-display text-2xl sm:text-[2rem] tracking-[4px] text-primary">
        VURA
      </Link>

      {/* Desktop links */}
      <div className="hidden lg:flex items-center gap-8">
        {navLinks.map((l) => (
          <a
            key={l.href}
            href={l.href}
            className="text-foreground/80 text-xs font-bold tracking-[2px] uppercase hover:text-primary transition-colors"
          >
            {l.label}
          </a>
        ))}
      </div>

      <div className="hidden md:block">
        <a
          href="#aplicacao"
          className="inline-flex items-center justify-center bg-primary hover:bg-primary-hover text-primary-foreground font-black text-xs tracking-[2px] uppercase px-7 py-3 rounded-md transition-colors"
        >
          Aplicar
        </a>
      </div>

      {/* Mobile toggle */}
      <button
        className="md:hidden text-foreground"
        onClick={() => setIsOpen(!isOpen)}
        aria-label="Menu"
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Mobile menu */}
      {isOpen && (
        <div className="absolute top-full left-0 right-0 bg-background border-b border-border p-6 md:hidden flex flex-col gap-5">
          {navLinks.map((l) => (
            <a
              key={l.href}
              href={l.href}
              onClick={() => setIsOpen(false)}
              className="text-foreground text-sm font-bold tracking-[2px] uppercase hover:text-primary transition-colors"
            >
              {l.label}
            </a>
          ))}
          <a
            href="#aplicacao"
            onClick={() => setIsOpen(false)}
            className="inline-flex items-center justify-center bg-primary hover:bg-primary-hover text-primary-foreground font-black text-xs tracking-[2px] uppercase w-full py-3 rounded-md transition-colors"
          >
            Aplicar
          </a>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
