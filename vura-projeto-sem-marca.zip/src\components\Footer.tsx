import { Instagram, Linkedin, MapPin, Mail, MessageCircle } from "lucide-react";

const navLinks = [
  { label: "Método", href: "#metodo" },
  { label: "Serviços", href: "#servicos" },
  { label: "Cases", href: "#cases" },
  { label: "Depoimentos", href: "#depoimentos" },
  { label: "FAQ", href: "#faq" },
];

const Footer = () => {
  const year = new Date().getFullYear();
  return (
    <footer className="bg-secondary border-t border-border px-4 sm:px-6 md:px-12 pt-12 sm:pt-16 pb-6">
      <div className="container mx-auto">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-10">
          <div className="col-span-2 md:col-span-1">
            <a
              href="/"
              className="font-display text-[2rem] tracking-[4px] text-primary"
            >
              VURA
            </a>
            <p className="text-muted-foreground text-sm mt-3 max-w-[260px]">
              Marketing esportivo orientado a resultado. Mais alunos, mais inscrições, mais autoridade.
            </p>
          </div>

          <div>
            <h4 className="font-display text-sm tracking-[3px] uppercase mb-4">
              Navegação
            </h4>
            <ul className="flex flex-col gap-2.5">
              {navLinks.map((l) => (
                <li key={l.href}>
                  <a
                    href={l.href}
                    className="text-muted-foreground text-sm hover:text-primary transition-colors"
                  >
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-display text-sm tracking-[3px] uppercase mb-4">
              Contato
            </h4>
            <ul className="flex flex-col gap-3 text-sm text-muted-foreground">
              <li>
                <a
                  href="https://wa.me/5582991050603"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 hover:text-primary transition-colors"
                >
                  <MessageCircle className="h-4 w-4" /> +55 82 99105-0603
                </a>
              </li>
              <li>
                <a
                  href="mailto:suportevura@gmail.com"
                  className="flex items-center gap-2 hover:text-primary transition-colors"
                >
                  <Mail className="h-4 w-4" /> suportevura@gmail.com
                </a>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="h-4 w-4" /> Maceió/AL · Atendimento Brasil
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-display text-sm tracking-[3px] uppercase mb-4">
              Redes
            </h4>
            <div className="flex items-center gap-3">
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="h-10 w-10 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary transition-colors"
              >
                <Instagram className="h-4 w-4" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="LinkedIn"
                className="h-10 w-10 rounded-full border border-border flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary transition-colors"
              >
                <Linkedin className="h-4 w-4" />
              </a>
            </div>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs text-muted-foreground">
          <p>© {year} Vura — Agência de Marketing Esportivo. Todos os direitos reservados.</p>
          <p className="opacity-60">Feito com performance em mente.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
