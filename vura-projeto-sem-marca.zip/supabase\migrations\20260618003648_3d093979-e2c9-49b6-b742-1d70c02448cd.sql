
-- Comentários em português nas colunas da tabela leads
COMMENT ON TABLE public.leads IS 'Leads capturados pela landing page (aplicações ao Método 30/30)';
COMMENT ON COLUMN public.leads.id IS 'Identificador único do lead';
COMMENT ON COLUMN public.leads.created_at IS 'Data e hora de criação';
COMMENT ON COLUMN public.leads.name IS 'Nome completo';
COMMENT ON COLUMN public.leads.phone IS 'WhatsApp / Telefone';
COMMENT ON COLUMN public.leads.business_type IS 'Tipo de negócio (academia, box, estúdio, escolinha, lutas, beach_tennis, personal, evento, outro)';
COMMENT ON COLUMN public.leads.source IS 'Origem do lead (ex: landing)';
COMMENT ON COLUMN public.leads.instagram IS 'Instagram do negócio';
COMMENT ON COLUMN public.leads.audience_size IS 'Quantidade de alunos ativos';
COMMENT ON COLUMN public.leads.revenue_range IS 'Faixa de faturamento mensal';
COMMENT ON COLUMN public.leads.main_challenge IS 'Principal desafio do negócio';
COMMENT ON COLUMN public.leads.marketing_investment IS 'Já investe em marketing';
COMMENT ON COLUMN public.leads.ads_budget IS 'Orçamento mensal de anúncios';
COMMENT ON COLUMN public.leads.goal_90d IS 'Objetivo para os próximos 90 dias';
COMMENT ON COLUMN public.leads.score IS 'Pontuação do lead (0-12)';
COMMENT ON COLUMN public.leads.temperature IS 'Temperatura do lead (frio, morno, quente)';

-- View totalmente em português com valores traduzidos
DROP VIEW IF EXISTS public.leads_pt;
CREATE VIEW public.leads_pt AS
SELECT
  id AS "ID",
  to_char(created_at AT TIME ZONE 'America/Sao_Paulo', 'DD/MM/YYYY HH24:MI') AS "Data de Cadastro",
  name AS "Nome",
  phone AS "WhatsApp",
  instagram AS "Instagram",
  CASE business_type
    WHEN 'academia' THEN 'Academia'
    WHEN 'box' THEN 'Box / CrossFit'
    WHEN 'estudio' THEN 'Estúdio'
    WHEN 'escolinha' THEN 'Escolinha Esportiva'
    WHEN 'lutas' THEN 'Lutas'
    WHEN 'beach_tennis' THEN 'Beach Tennis'
    WHEN 'personal' THEN 'Personal Trainer'
    WHEN 'evento' THEN 'Evento'
    WHEN 'outro' THEN 'Outro'
    ELSE business_type
  END AS "Tipo de Negócio",
  CASE audience_size
    WHEN 'lt_50' THEN 'Menos de 50 alunos'
    WHEN '50_100' THEN '50 a 100 alunos'
    WHEN '100_200' THEN '100 a 200 alunos'
    WHEN '200_500' THEN '200 a 500 alunos'
    WHEN 'gt_500' THEN 'Mais de 500 alunos'
    ELSE audience_size
  END AS "Alunos Ativos",
  CASE revenue_range
    WHEN 'lt_10k' THEN 'Até R$ 10 mil'
    WHEN '10_25k' THEN 'R$ 10 a 25 mil'
    WHEN '25_50k' THEN 'R$ 25 a 50 mil'
    WHEN '50_100k' THEN 'R$ 50 a 100 mil'
    WHEN 'gt_100k' THEN 'Mais de R$ 100 mil'
    ELSE revenue_range
  END AS "Faturamento Mensal",
  CASE main_challenge
    WHEN 'captacao' THEN 'Captação de novos alunos'
    WHEN 'retencao' THEN 'Retenção de alunos'
    WHEN 'posicionamento' THEN 'Posicionamento de marca'
    WHEN 'previsibilidade' THEN 'Falta de previsibilidade'
    WHEN 'gestao' THEN 'Gestão / operação'
    WHEN 'escalar' THEN 'Escalar o negócio'
    ELSE main_challenge
  END AS "Principal Desafio",
  CASE marketing_investment
    WHEN 'atualmente' THEN 'Invisto atualmente'
    WHEN 'ja_investi' THEN 'Já investi antes'
    WHEN 'nunca' THEN 'Nunca investi'
    ELSE marketing_investment
  END AS "Investe em Marketing",
  CASE ads_budget
    WHEN 'zero' THEN 'R$ 0'
    WHEN 'lt_500' THEN 'Até R$ 500'
    WHEN '500_1500' THEN 'R$ 500 a 1.500'
    WHEN '1500_3000' THEN 'R$ 1.500 a 3.000'
    WHEN 'gt_3000' THEN 'Mais de R$ 3.000'
    ELSE ads_budget
  END AS "Orçamento de Anúncios",
  CASE goal_90d
    WHEN 'previsibilidade' THEN 'Crescer de forma previsível'
    WHEN 'matriculas' THEN 'Aumentar matrículas'
    WHEN 'autoridade' THEN 'Construir autoridade'
    WHEN 'estruturar' THEN 'Estruturar o marketing'
    WHEN 'escalar' THEN 'Escalar com anúncios'
    ELSE goal_90d
  END AS "Objetivo em 90 dias",
  score AS "Pontuação",
  CASE temperature
    WHEN 'hot' THEN '🔥 Quente'
    WHEN 'warm' THEN '🌤️ Morno'
    WHEN 'cold' THEN '❄️ Frio'
    ELSE temperature
  END AS "Temperatura",
  source AS "Origem"
FROM public.leads
ORDER BY created_at DESC;

GRANT SELECT ON public.leads_pt TO authenticated;
GRANT ALL ON public.leads_pt TO service_role;
