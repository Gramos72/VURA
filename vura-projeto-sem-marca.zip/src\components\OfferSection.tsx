import WhatsAppButton from "./WhatsAppButton";
import FadeIn from "./FadeIn";

const phases = [
  {
    number: "30",
    phase: "Fase 01 — Primeiros 30 dias",
    title: "Estruturar",
    items: [
      "Diagnóstico completo do negócio",
      "Posicionamento e identidade da marca",
      "Criação da estratégia digital",
      "Ativação das redes sociais",
      "Configuração dos anúncios",
      "Definição de métricas e metas",
    ],
  },
  {
    number: "30",
    phase: "Fase 02 — Próximos 30 dias",
    title: "Escalar",
    items: [
      "Otimização baseada em dados reais",
      "Escala dos anúncios que convertem",
      "Conteúdo de autoridade no nicho",
      "Funil de captação automatizado",
      "Relatório semanal de performance",
      "Crescimento previsível",
    ],
  },
];

const OfferSection = () => {
  return (
    <section id="metodo" className="py-16 sm:py-24 px-4 sm:px-6 md:px-12 bg-background">
      <div className="container mx-auto">
        <FadeIn>
          <div className="flex items-center gap-3 text-xs font-bold tracking-[4px] uppercase text-primary mb-5">
            <span className="w-8 h-0.5 bg-primary" />
            O método
          </div>
          <h2 className="font-display text-[clamp(2.2rem,5vw,5rem)] tracking-wide leading-none uppercase max-w-[700px]">
            Em 60 dias, você vê a <span className="text-primary">diferença.</span>
          </h2>
        </FadeIn>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 mt-10 sm:mt-14">
          {phases.map((phase, i) => (
            <div
              key={i}
              className="bg-card border border-border p-6 sm:p-12 relative overflow-hidden hover:border-primary transition-colors rounded-xl"
            >
              <span className="absolute top-3 right-5 font-display text-[4rem] sm:text-[6rem] leading-none text-primary/10 tracking-tight">
                {phase.number}
              </span>
              <div className="text-[0.65rem] sm:text-xs font-bold tracking-[3px] sm:tracking-[4px] uppercase text-primary mb-3">
                {phase.phase}
              </div>
              <h3 className="font-display text-[1.8rem] sm:text-[2.2rem] tracking-wide mb-4 sm:mb-5">{phase.title}</h3>
              <ul className="flex flex-col gap-2 sm:gap-2.5">
                {phase.items.map((item, j) => (
                  <li key={j} className="flex items-center gap-3 text-muted-foreground text-xs sm:text-sm">
                    <span className="text-primary font-black flex-shrink-0">→</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div className="lg:col-span-2 bg-primary text-primary-foreground p-6 sm:p-10 flex flex-col sm:flex-row flex-wrap items-center justify-between gap-4 sm:gap-6 rounded-xl">
            <p className="font-display text-xl sm:text-2xl tracking-wide max-w-[600px] text-center sm:text-left">
              Sem achismo. Você vai ver os números, os leads e os alunos novos chegando.
            </p>
            <WhatsAppButton
              text="Quero o 30/30 →"
              className="bg-background text-primary hover:bg-background/90 font-black text-xs sm:text-sm tracking-[2px] uppercase px-6 sm:px-8 py-3 sm:py-4 w-full sm:w-auto"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default OfferSection;
