import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp } from "lucide-react";

interface CaseCardProps {
  title: string;
  description: string;
  result: string;
}

const CaseCard = ({ title, description, result }: CaseCardProps) => {
  return (
    <Card className="border-border bg-gradient-card hover:shadow-card transition-all duration-300">
      <CardContent className="p-6">
        <div className="mb-4 flex items-center justify-between">
          <TrendingUp className="h-8 w-8 text-primary" />
          <span className="text-2xl font-bold text-primary">{result}</span>
        </div>
        <h3 className="mb-2 text-xl font-bold text-foreground">{title}</h3>
        <p className="text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  );
};

export default CaseCard;
