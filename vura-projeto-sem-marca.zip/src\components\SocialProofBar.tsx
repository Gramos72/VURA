const stats = [
  { value: "+R$ 18MI", label: "gerados para operações esportivas" },
  { value: "+40", label: "operações ativas no método" },
  { value: "12", label: "estados atendidos" },
  { value: "94%", label: "de retenção de clientes" },
];

const SocialProofBar = () => {
  return (
    <section className="border-y border-border bg-card/40">
      <div className="container mx-auto max-w-[1280px] px-4 sm:px-6 md:px-12 py-6 sm:py-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-4 gap-y-6 sm:gap-x-8">
          {stats.map((s) => (
            <div
              key={s.label}
              className="flex flex-col items-start lg:items-center text-left lg:text-center"
            >
              <span className="font-display text-3xl sm:text-4xl lg:text-5xl text-primary tracking-wide leading-none">
                {s.value}
              </span>
              <span className="mt-2 text-[0.6rem] sm:text-[0.7rem] font-bold tracking-[1.5px] uppercase text-muted-foreground leading-tight">
                {s.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SocialProofBar;
