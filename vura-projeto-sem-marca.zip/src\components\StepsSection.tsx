import FadeIn from "./FadeIn";

const steps = [
  { num: "01", title: "Conversa", desc: "Você conta o que tá travando. A gente ouve e entende o cenário real." },
  { num: "02", title: "Plano", desc: "Criamos a estratégia sob medida pro seu negócio — sem fórmula pronta." },
  { num: "03", title: "Ação", desc: "Colocamos tudo pra rodar: anúncios, conteúdo e funil." },
  { num: "04", title: "Resultado", desc: "Você acompanha os números toda semana. Transparência total." },
  { num: "05", title: "Escala", desc: "O que funciona, a gente dobra. Crescimento contínuo." },
];

const StepsSection = () => {
  return (
    <section className="py-16 sm:py-24 px-4 sm:px-6 md:px-12 bg-secondary">
      <div className="container mx-auto">
        <FadeIn>
          <div className="flex items-center gap-3 text-xs font-bold tracking-[4px] uppercase text-primary mb-5">
            <span className="w-8 h-0.5 bg-primary" />
            Como funciona
          </div>
          <h2 className="font-display text-[clamp(2.2rem,5vw,5rem)] tracking-wide leading-none uppercase max-w-[700px]">
            Simples, direto e sem <span className="text-primary">enrolação.</span>
          </h2>
        </FadeIn>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-6 sm:gap-8 mt-10 sm:mt-14 relative">
          <div className="hidden md:block absolute top-8 left-[10%] right-[10%] h-[2px] bg-gradient-to-r from-transparent via-primary to-transparent" />

          {steps.map((s, i) => (
            <div key={i} className={`flex flex-col items-center text-center group ${i === 4 ? 'col-span-2 sm:col-span-1' : ''}`}>
              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-card border-2 border-border flex items-center justify-center font-display text-xl sm:text-2xl tracking-wide mb-4 sm:mb-5 relative z-10 transition-all group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary">
                {s.num}
              </div>
              <h4 className="font-display text-base sm:text-lg tracking-wide mb-1 sm:mb-2">{s.title}</h4>
              <p className="text-muted-foreground text-[0.7rem] sm:text-xs leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StepsSection;
