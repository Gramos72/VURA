ALTER TABLE public.leads
  ADD CONSTRAINT leads_business_type_check
  CHECK (business_type IN ('academia','crossfit','estudio','personal','evento','outro'));

ALTER TABLE public.leads
  ADD CONSTRAINT leads_source_check
  CHECK (source IN ('landing','whatsapp','instagram','referral','other'));

ALTER TABLE public.leads
  ADD CONSTRAINT leads_phone_format_check
  CHECK (phone ~ '^[0-9()\-\s+]{8,20}$');