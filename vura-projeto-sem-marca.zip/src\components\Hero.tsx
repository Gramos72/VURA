import heroOperator from "@/assets/hero-operator.jpg";

const stats = [
  { value: "+127%", label: "Matrículas em 60 dias" },
  { value: "3.2x", label: "Retorno sobre ad spend" },
];

const niches = [
  "Academias",
  "Boxes",
  "Estúdios",
  "Arenas",
  "Escolinhas",
  "Lutas",
  "Beach Tennis",
];

const partners = ["BOX·RJ", "ARENA·SP", "FORCA·MG", "PRIME·BA", "ELITE·DF"];

const Hero = () => {
  return (
    <section className="relative overflow-hidden pt-28 sm:pt-36 pb-14 sm:pb-24 px-4 sm:px-6 md:px-12 bg-background">
      {/* Ambient background glow */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <div className="absolute top-1/3 -left-32 w-[600px] h-[600px] rounded-full bg-primary/10 blur-[120px]" />
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] rounded-full bg-primary/5 blur-[100px]" />
      </div>

      <div className="container mx-auto max-w-[1280px] relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-[1.15fr_1fr] gap-10 lg:gap-16 items-center">
          {/* LEFT: copy + CTA + logo wall */}
          <div>
            <p className="text-[0.6rem] sm:text-xs font-bold tracking-[2px] sm:tracking-[4px] uppercase text-muted-foreground mb-4 sm:mb-7">
              Procurando uma operadora de crescimento esportivo?
            </p>

            <h1 className="font-display text-[clamp(2.25rem,6.5vw,6.5rem)] leading-[0.95] tracking-wide uppercase">
              Tenha um time{" "}
              <span className="text-primary">feito sob medida</span>{" "}
              para escalar seu negócio esportivo
            </h1>

            {/* Nichos atendidos */}
            <div className="mt-5 sm:mt-7 flex flex-wrap gap-1.5 sm:gap-2">
              {niches.map((n) => (
                <span
                  key={n}
                  className="inline-flex items-center rounded-full border border-border bg-card/40 px-3 py-1 text-[0.6rem] sm:text-[0.7rem] font-bold tracking-[1.5px] uppercase text-foreground/70"
                >
                  {n}
                </span>
              ))}
            </div>

            <div className="mt-7 sm:mt-11 flex flex-col sm:flex-row gap-3 sm:gap-4">
              <a
                href="#aplicacao"
                className="inline-flex items-center justify-center bg-primary hover:bg-primary-hover text-primary-foreground font-black text-xs sm:text-sm tracking-[2px] uppercase px-6 sm:px-11 py-4 sm:py-6 rounded-md transition-colors"
              >
                Quero mais informações
              </a>
              <a
                href="#metodo"
                className="inline-flex items-center justify-center border border-border text-foreground font-bold text-xs sm:text-sm tracking-[2px] uppercase px-6 sm:px-11 py-4 sm:py-6 rounded-md hover:border-primary hover:text-primary transition-all"
              >
                Conhecer o método →
              </a>
            </div>

            {/* Logo wall */}
            <div className="mt-10 sm:mt-14">
              <p className="text-[0.6rem] sm:text-xs font-bold uppercase tracking-[1.5px] text-muted-foreground mb-3">
                Operações esportivas parceiras
              </p>
              <div className="flex items-center gap-2 sm:gap-4 overflow-x-auto -mx-4 px-4 sm:mx-0 sm:px-0 sm:overflow-visible scrollbar-hide pb-1 sm:pb-0">
                {partners.map((p) => (
                  <div
                    key={p}
                    className="shrink-0 h-9 sm:h-11 px-3 sm:px-4 rounded-md border border-border bg-card/50 flex items-center justify-center font-display text-[0.65rem] sm:text-xs tracking-[2px] text-foreground/65"
                  >
                    {p}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* RIGHT: portrait + floating stat cards */}
          <div className="relative mx-auto w-full max-w-[420px] lg:max-w-none mt-4 lg:mt-0">
            <div className="relative aspect-[4/5] rounded-xl overflow-hidden">
              <img
                src={heroOperator}
                alt="Dono de operação esportiva — método Vura 30/30"
                width={896}
                height={1120}
                className="absolute inset-0 w-full h-full object-cover"
              />
              {/* Edge fades to blend with background */}
              <div
                className="absolute inset-0"
                style={{
                  background:
                    "linear-gradient(90deg, hsl(0 0% 3% / 0.55) 0%, transparent 25%, transparent 70%, hsl(0 0% 3% / 0.85) 100%), linear-gradient(180deg, transparent 60%, hsl(0 0% 3% / 0.9) 100%)",
                }}
              />
            </div>

            {/* Stat cards: floating on desktop, stacked below image on mobile/tablet */}
            <div className="hidden lg:block">
              <div className="absolute top-1/4 -translate-y-1/2 -left-12 bg-card/85 backdrop-blur-md border border-primary/30 rounded-xl px-5 py-4 shadow-2xl max-w-[200px]">
                <p className="font-display text-4xl text-primary leading-none tracking-wide">
                  {stats[0].value}
                </p>
                <p className="text-[0.7rem] font-bold tracking-[1.5px] uppercase text-foreground/75 mt-1.5 leading-tight">
                  {stats[0].label}
                </p>
              </div>
              <div className="absolute bottom-16 -right-8 bg-card/85 backdrop-blur-md border border-primary/30 rounded-xl px-5 py-4 shadow-2xl max-w-[200px]">
                <p className="font-display text-4xl text-primary leading-none tracking-wide">
                  {stats[1].value}
                </p>
                <p className="text-[0.7rem] font-bold tracking-[1.5px] uppercase text-foreground/75 mt-1.5 leading-tight">
                  {stats[1].label}
                </p>
              </div>
            </div>

            <div className="lg:hidden mt-4 grid grid-cols-2 gap-3">
              {stats.map((s) => (
                <div
                  key={s.label}
                  className="bg-card/85 backdrop-blur-md border border-primary/30 rounded-xl px-3 py-3 shadow-2xl"
                >
                  <p className="font-display text-2xl sm:text-3xl text-primary leading-none tracking-wide">
                    {s.value}
                  </p>
                  <p className="text-[0.55rem] sm:text-[0.65rem] font-bold tracking-[1.2px] uppercase text-foreground/75 mt-1.5 leading-tight">
                    {s.label}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
