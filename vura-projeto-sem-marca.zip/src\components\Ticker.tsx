const items = [
  "ACADEMIAS", "BOXES", "ESTÚDIOS", "EVENTOS ESPORTIVOS",
  "CROSSFIT", "PILATES", "BEACH TENNIS", "JIU-JITSU", "SURF",
];

const Ticker = () => {
  const content = items.map((item, i) => (
    <span key={i}>
      <span className="font-display text-lg tracking-[4px] mx-7">{item}</span>
      <span className="opacity-40 mx-1">✦</span>
    </span>
  ));

  return (
    <div className="bg-primary text-primary-foreground py-3.5 overflow-hidden whitespace-nowrap">
      <div className="inline-block animate-ticker">
        {content}
        {content}
      </div>
    </div>
  );
};

export default Ticker;
