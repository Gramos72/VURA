import FadeIn from "./FadeIn";

const CtaFinal = () => {
  return (
    <section className="relative bg-primary py-20 sm:py-28 px-4 sm:px-6 md:px-12 text-center overflow-hidden">
      <span className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 font-display text-[28vw] text-background/[0.06] whitespace-nowrap pointer-events-none tracking-[20px]">
        VURA
      </span>

      <FadeIn>
        <p className="relative text-[0.65rem] sm:text-xs font-bold tracking-[4px] uppercase text-primary-foreground/70 mb-5">
          Próxima janela de aplicações
        </p>
        <h2 className="relative font-display text-[clamp(2.2rem,5.5vw,5.5rem)] tracking-wide text-primary-foreground leading-[0.95] uppercase mb-5 sm:mb-7 max-w-[900px] mx-auto">
          Pronto para entrar no método 30/30?
        </h2>
        <p className="relative text-primary-foreground/75 text-base sm:text-lg max-w-[600px] mx-auto mb-9 sm:mb-11 px-2 leading-relaxed">
          Aplique para o Diagnóstico Estratégico. Nossa equipe avalia o seu perfil
          e responde em até 24 horas úteis.
        </p>
        <a
          href="#aplicacao"
          className="relative inline-flex items-center justify-center bg-background text-primary hover:bg-background/90 font-black text-xs sm:text-sm tracking-[2px] uppercase px-9 sm:px-14 py-4 sm:py-5 rounded-md transition-colors"
        >
          Aplicar agora
        </a>
      </FadeIn>
    </section>
  );
};

export default CtaFinal;
