import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { MessageCircle } from "lucide-react";
import FadeIn from "./FadeIn";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";

const leadSchema = z.object({
  name: z
    .string()
    .trim()
    .min(2, "Nome muito curto")
    .max(80, "Nome muito longo"),
  phone: z
    .string()
    .trim()
    .min(10, "Informe um WhatsApp válido com DDD")
    .max(20, "Telefone muito longo")
    .regex(/^[0-9()\-\s+]+$/, "Use apenas números e símbolos"),
  business_type: z
    .string()
    .min(2, "Selecione o tipo de negócio")
    .max(40),
});

const businessOptions = [
  { value: "academia", label: "Academia" },
  { value: "crossfit", label: "Box de CrossFit" },
  { value: "estudio", label: "Estúdio (Pilates / Funcional)" },
  { value: "personal", label: "Personal Trainer" },
  { value: "evento", label: "Evento Esportivo" },
  { value: "outro", label: "Outro" },
];

const WHATSAPP_NUMBER = "5582991050603";

const LeadFormSection = () => {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [businessType, setBusinessType] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    const parsed = leadSchema.safeParse({
      name,
      phone,
      business_type: businessType,
    });

    if (!parsed.success) {
      const fieldErrors: Record<string, string> = {};
      parsed.error.issues.forEach((issue) => {
        const key = issue.path[0] as string;
        if (!fieldErrors[key]) fieldErrors[key] = issue.message;
      });
      setErrors(fieldErrors);
      return;
    }

    setLoading(true);
    const { error } = await supabase.from("leads").insert({
      name: parsed.data.name,
      phone: parsed.data.phone,
      business_type: parsed.data.business_type,
      source: "landing",
    });
    setLoading(false);

    if (error) {
      toast.error("Não foi possível enviar agora. Tenta de novo em instantes.");
      return;
    }

    toast.success("Recebemos seu contato! Já vamos te chamar.");

    const businessLabel =
      businessOptions.find((b) => b.value === parsed.data.business_type)?.label ||
      parsed.data.business_type;
    const message = `Olá, sou ${parsed.data.name}. Tenho um(a) ${businessLabel} e quero saber mais sobre a Vura. Meu WhatsApp: ${parsed.data.phone}`;
    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank", "noopener,noreferrer");

    setName("");
    setPhone("");
    setBusinessType("");
  };

  return (
    <section
      id="contato"
      className="py-16 sm:py-24 px-4 sm:px-6 md:px-12 bg-background"
    >
      <div className="container mx-auto max-w-[1100px]">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center">
          <FadeIn>
            <div className="flex items-center gap-3 text-xs font-bold tracking-[4px] uppercase text-primary mb-5">
              <span className="w-8 h-0.5 bg-primary" />
              Diagnóstico gratuito
            </div>
            <h2 className="font-display text-[clamp(2rem,5vw,4.5rem)] tracking-wide leading-none uppercase">
              Bora ver onde tá <span className="text-primary">travando?</span>
            </h2>
            <p className="text-muted-foreground text-sm sm:text-base mt-5 leading-relaxed max-w-[460px]">
              Deixa seu contato. Em até 24h um especialista chama no WhatsApp pra
              uma conversa de 30 minutos — sem compromisso, sem enrolação. A gente
              mostra exatamente o que tá segurando o crescimento.
            </p>
            <ul className="mt-6 flex flex-col gap-2.5 text-sm text-foreground/80">
              <li className="flex items-center gap-3">
                <span className="text-primary font-black">→</span> Análise do seu
                posicionamento e funil atual
              </li>
              <li className="flex items-center gap-3">
                <span className="text-primary font-black">→</span> 3 ações
                prioritárias pra aplicar essa semana
              </li>
              <li className="flex items-center gap-3">
                <span className="text-primary font-black">→</span> Sem cobrança e
                sem pressão pra fechar
              </li>
            </ul>
          </FadeIn>

          <FadeIn delay={150}>
            <form
              onSubmit={handleSubmit}
              className="bg-card border border-border rounded-xl p-6 sm:p-8 flex flex-col gap-4"
              noValidate
            >
              <div>
                <label className="text-[0.65rem] font-bold tracking-[3px] uppercase text-muted-foreground mb-2 block">
                  Seu nome
                </label>
                <Input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  maxLength={80}
                  placeholder="Como prefere ser chamado(a)"
                  className="bg-background border-border focus-visible:ring-primary"
                  aria-invalid={!!errors.name}
                />
                {errors.name && (
                  <p className="text-destructive text-xs mt-1.5">{errors.name}</p>
                )}
              </div>

              <div>
                <label className="text-[0.65rem] font-bold tracking-[3px] uppercase text-muted-foreground mb-2 block">
                  WhatsApp
                </label>
                <Input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  maxLength={20}
                  inputMode="tel"
                  placeholder="(82) 99105-0603"
                  className="bg-background border-border focus-visible:ring-primary"
                  aria-invalid={!!errors.phone}
                />
                {errors.phone && (
                  <p className="text-destructive text-xs mt-1.5">{errors.phone}</p>
                )}
              </div>

              <div>
                <label className="text-[0.65rem] font-bold tracking-[3px] uppercase text-muted-foreground mb-2 block">
                  Tipo de negócio
                </label>
                <Select value={businessType} onValueChange={setBusinessType}>
                  <SelectTrigger
                    className="bg-background border-border focus:ring-primary"
                    aria-invalid={!!errors.business_type}
                  >
                    <SelectValue placeholder="Selecione uma opção" />
                  </SelectTrigger>
                  <SelectContent>
                    {businessOptions.map((opt) => (
                      <SelectItem key={opt.value} value={opt.value}>
                        {opt.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.business_type && (
                  <p className="text-destructive text-xs mt-1.5">
                    {errors.business_type}
                  </p>
                )}
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="bg-primary hover:bg-primary-hover text-primary-foreground font-black text-xs sm:text-sm tracking-[2px] uppercase py-6 mt-2"
              >
                <MessageCircle className="mr-2 h-5 w-5" />
                {loading ? "Enviando..." : "Quero meu diagnóstico"}
              </Button>

              <p className="text-muted-foreground text-[0.65rem] text-center">
                Seus dados são tratados com segurança. Sem spam, prometido.
              </p>
            </form>
          </FadeIn>
        </div>
      </div>
    </section>
  );
};

export default LeadFormSection;
