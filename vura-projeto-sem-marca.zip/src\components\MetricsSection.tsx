import FadeIn from "./FadeIn";

const metrics = [
  { value: "30", label: "Dias pro primeiro resultado" },
  { value: "3x", label: "Mais leads que fazer sozinho" },
  { value: "100%", label: "Focados em esporte" },
  { value: "0", label: "Ação sem propósito" },
];

const MetricsSection = () => {
  return (
    <section className="py-16 sm:py-24 px-4 sm:px-6 md:px-12 bg-background">
      <div className="container mx-auto">
        <FadeIn>
          <div className="flex items-center gap-3 text-xs font-bold tracking-[4px] uppercase text-primary mb-5">
            <span className="w-8 h-0.5 bg-primary" />
            Por que a Vura
          </div>
          <h2 className="font-display text-[clamp(2.2rem,5vw,5rem)] tracking-wide leading-none uppercase max-w-[700px]">
            Números que você <span className="text-primary">pode confiar.</span>
          </h2>
        </FadeIn>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-[2px] bg-border mt-10 sm:mt-14">
          {metrics.map((m, i) => (
            <div key={i} className="bg-card p-6 sm:p-12 text-center">
              <div className="font-display text-[2.5rem] sm:text-[4.5rem] leading-none text-primary tracking-tight">
                {m.value}
              </div>
              <p className="text-muted-foreground text-[0.65rem] sm:text-xs mt-2 sm:mt-3 uppercase tracking-[1px] sm:tracking-[2px]">{m.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default MetricsSection;
