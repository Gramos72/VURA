import FadeIn from "./FadeIn";

const ManifestoDivider = () => {
  return (
    <section className="relative overflow-hidden bg-background py-24 sm:py-36 px-4 sm:px-6 md:px-12 border-y border-border">
      {/* Background mark */}
      <span
        aria-hidden
        className="pointer-events-none absolute inset-0 flex items-center justify-center font-display text-[32vw] leading-none tracking-[20px] text-primary/[0.05] select-none whitespace-nowrap"
      >
        30/30
      </span>

      {/* Ambient glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full bg-primary/10 blur-[140px]" />
      </div>

      <FadeIn>
        <div className="relative container mx-auto max-w-[1100px] text-center">
          <p className="text-[0.65rem] sm:text-xs font-bold tracking-[4px] uppercase text-primary mb-6">
            Manifesto Vura
          </p>
          <h2 className="font-display text-[clamp(2rem,6vw,5.5rem)] leading-[0.95] tracking-wide uppercase">
            Não vendemos marketing.{" "}
            <span className="text-primary">Construímos operações</span>{" "}
            esportivas que crescem com previsibilidade.
          </h2>
        </div>
      </FadeIn>
    </section>
  );
};

export default ManifestoDivider;
