import { useState, useEffect, useCallback } from "react";
import FadeIn from "./FadeIn";
import { Star, ChevronLeft, ChevronRight } from "lucide-react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  type CarouselApi,
} from "@/components/ui/carousel";

const testimonials = [
  {
    name: "Rafael Mendes",
    role: "Dono de academia · Maceió/AL",
    quote:
      "Em 45 dias, minha academia saiu de 80 alunos pra 140. Eu tentava de tudo sozinho, mas faltava estratégia. A Vura mudou o jogo.",
    result: "+75% de alunos",
    stars: 5,
  },
  {
    name: "Camila Torres",
    role: "Gestora de box de CrossFit · Recife/PE",
    quote:
      "Antes, meu Instagram era bonito mas não trazia ninguém. Agora cada post tem propósito e os leads chegam todo dia pelo WhatsApp.",
    result: "3x mais leads",
    stars: 5,
  },
  {
    name: "Lucas Ferreira",
    role: "Organizador de eventos esportivos · SP",
    quote:
      "Lotamos nosso último evento em 2 semanas. A Vura entende esporte de verdade, não é agência genérica que trata tudo igual.",
    result: "Evento lotado em 14 dias",
    stars: 5,
  },
  {
    name: "Fernanda Lima",
    role: "Dona de estúdio de pilates · Salvador/BA",
    quote:
      "Achava que marketing digital não funcionava pro meu nicho. Em 2 meses, triplicamos os agendamentos e tive que contratar mais instrutora.",
    result: "+200% agendamentos",
    stars: 5,
  },
  {
    name: "Thiago Santos",
    role: "Personal trainer · Curitiba/PR",
    quote:
      "Eu vivia de indicação e tinha medo de investir em tráfego. A Vura me mostrou que dá pra escalar sem perder a essência. Hoje tenho lista de espera.",
    result: "Lista de espera cheia",
    stars: 5,
  },
  {
    name: "Juliana Costa",
    role: "Gestora de escola de natação · BH/MG",
    quote:
      "A gente tinha 3 turmas vazias. Com a estratégia da Vura, lotamos tudo e abrimos mais 2 horários em menos de 60 dias.",
    result: "5 turmas lotadas",
    stars: 5,
  },
];

const TestimonialsSection = () => {
  const [api, setApi] = useState<CarouselApi>();
  const [current, setCurrent] = useState(0);
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!api) return;
    setCount(api.scrollSnapList().length);
    setCurrent(api.selectedScrollSnap());
    api.on("select", () => setCurrent(api.selectedScrollSnap()));
  }, [api]);

  const scrollTo = useCallback(
    (index: number) => api?.scrollTo(index),
    [api]
  );

  return (
    <section id="depoimentos" className="py-16 sm:py-24 px-4 sm:px-6 md:px-12 bg-secondary">
      <div className="container mx-auto">
        <FadeIn>
          <div className="flex items-center gap-3 text-xs font-bold tracking-[4px] uppercase text-primary mb-5">
            <span className="w-8 h-0.5 bg-primary" />
            Prova social
          </div>
          <h2 className="font-display text-[clamp(2rem,5vw,4.5rem)] tracking-wide leading-none uppercase max-w-[800px]">
            Quem confia na Vura,{" "}
            <span className="text-primary">cresce de verdade.</span>
          </h2>
        </FadeIn>

        <FadeIn delay={200}>
          <div className="relative mt-10 sm:mt-14">
            <Carousel
              setApi={setApi}
              opts={{ align: "start", loop: true }}
              className="w-full"
            >
              <CarouselContent className="-ml-4">
                {testimonials.map((t, i) => (
                  <CarouselItem
                    key={i}
                    className="pl-4 basis-full md:basis-1/3"
                  >
                    <div className="bg-card rounded-xl p-6 sm:p-8 flex flex-col justify-between h-full border border-border hover:border-primary/40 transition-colors duration-300">
                      <div>
                        <div className="flex gap-1 mb-4">
                          {Array.from({ length: t.stars }).map((_, j) => (
                            <Star
                              key={j}
                              className="h-4 w-4 fill-primary text-primary"
                            />
                          ))}
                        </div>
                        <p className="text-foreground text-sm sm:text-base leading-relaxed mb-6">
                          "{t.quote}"
                        </p>
                      </div>
                      <div>
                        <div className="inline-block bg-primary/10 text-primary text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full mb-4">
                          {t.result}
                        </div>
                        <div>
                          <p className="font-bold text-foreground">{t.name}</p>
                          <p className="text-muted-foreground text-xs">{t.role}</p>
                        </div>
                      </div>
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
            </Carousel>

            {/* Navigation arrows */}
            <button
              onClick={() => api?.scrollPrev()}
              className="absolute -left-2 sm:-left-5 top-1/2 -translate-y-1/2 z-10 h-10 w-10 rounded-full bg-primary/10 hover:bg-primary/20 text-primary flex items-center justify-center transition-colors"
              aria-label="Anterior"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              onClick={() => api?.scrollNext()}
              className="absolute -right-2 sm:-right-5 top-1/2 -translate-y-1/2 z-10 h-10 w-10 rounded-full bg-primary/10 hover:bg-primary/20 text-primary flex items-center justify-center transition-colors"
              aria-label="Próximo"
            >
              <ChevronRight className="h-5 w-5" />
            </button>

            {/* Dots */}
            <div className="flex justify-center gap-2 mt-8">
              {Array.from({ length: count }).map((_, i) => (
                <button
                  key={i}
                  onClick={() => scrollTo(i)}
                  className={`h-2.5 rounded-full transition-all duration-300 ${
                    i === current
                      ? "w-8 bg-primary"
                      : "w-2.5 bg-primary/25 hover:bg-primary/40"
                  }`}
                  aria-label={`Ir para slide ${i + 1}`}
                />
              ))}
            </div>
          </div>
        </FadeIn>
      </div>
    </section>
  );
};

export default TestimonialsSection;
