import { LucideIcon } from "lucide-react";

interface DifferentialCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
}

const DifferentialCard = ({ icon: Icon, title, description }: DifferentialCardProps) => {
  return (
    <div className="flex flex-col items-center text-center space-y-4 p-6 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors duration-300">
      <div className="inline-flex h-16 w-16 items-center justify-center rounded-full bg-primary/20">
        <Icon className="h-8 w-8 text-primary" />
      </div>
      <h3 className="text-xl font-bold text-foreground">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </div>
  );
};

export default DifferentialCard;
